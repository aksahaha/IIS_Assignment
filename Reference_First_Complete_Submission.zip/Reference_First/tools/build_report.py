"""Build the current question-input report and editable figure/source files."""

import copy
import json
import posixpath
import warnings
from html import escape
from pathlib import Path

from reportlab.graphics import renderPDF, renderSVG
from reportlab.graphics.shapes import Drawing, Line, Polygon, Rect, String
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Flowable, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer


ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"
OUT = ROOT / "output" / "pdf"
SOURCE = DOCS / "report_content.json"
INK = colors.HexColor("#111111")
MUTED = colors.HexColor("#53615A")
GREEN = colors.HexColor("#4F7960")
PAGE_W, PAGE_H = A4
WIDTH = PAGE_W - 96


def register_fonts():
    font_root = Path("C:/Windows/Fonts")
    fonts = {"RF": "calibri.ttf", "RF-Bold": "calibrib.ttf", "RF-Italic": "calibrii.ttf"}
    for name, filename in fonts.items():
        path = font_root / filename
        if not path.is_file():
            raise RuntimeError(f"Report font unavailable: {path}")
        pdfmetrics.registerFont(TTFont(name, str(path)))
    pdfmetrics.registerFontFamily("RF", normal="RF", bold="RF-Bold", italic="RF-Italic", boldItalic="RF-Bold")


def label(drawing, x, y, text, size=9.6, bold=False, color=INK):
    drawing.add(String(x, y, text, fontName="Helvetica-Bold" if bold else "Helvetica", fontSize=size, fillColor=color))


def arrow(drawing, points, dashed=False):
    for (x1, y1), (x2, y2) in zip(points, points[1:]):
        drawing.add(Line(x1, y1, x2, y2, strokeColor=MUTED, strokeWidth=0.85,
                         strokeDashArray=[3, 2] if dashed else None))
    (x1, y1), (x2, y2) = points[-2:]
    if abs(x2 - x1) > abs(y2 - y1):
        direction = 1 if x2 > x1 else -1
        vertices = [x2, y2, x2 - direction * 5, y2 - 2.5, x2 - direction * 5, y2 + 2.5]
    else:
        direction = 1 if y2 > y1 else -1
        vertices = [x2, y2, x2 - 2.5, y2 - direction * 5, x2 + 2.5, y2 - direction * 5]
    drawing.add(Polygon(vertices, fillColor=MUTED, strokeColor=MUTED, strokeWidth=0.2))


def node(drawing, x, y, title, lines, status="I", width=144, height=60):
    palette = {
        "I": ("#F1F6F2", "#78917C"),
        "S": ("#FFF7E9", "#B99B61"),
        "P": ("#EFF4F9", "#8098AC"),
    }
    fill, stroke = palette[status]
    drawing.add(Rect(x, y, width, height, rx=4, ry=4, fillColor=colors.HexColor(fill),
                     strokeColor=colors.HexColor(stroke), strokeWidth=0.8,
                     strokeDashArray=[4, 2] if status in {"S", "P"} else None))
    label(drawing, x + 8, y + height - 17, f"{title} [{status}]", 10.1, True)
    for index, line in enumerate(lines):
        label(drawing, x + 8, y + height - 33 - index * 12, line, 9.5)


def system_diagram():
    drawing = Drawing(520, 370)
    label(drawing, 12, 356, "I  Implemented controls", 9.3, True)
    label(drawing, 187, 356, "S  Simulated AI behaviour", 9.3, True)
    label(drawing, 391, 356, "P  Planned", 9.3, True)

    node(drawing, 12, 257, "Question form", ["Typed question", "Find references"])
    node(drawing, 182, 257, "Local HTTP API", ["Validate actions", "Keep session state"])
    node(drawing, 352, 257, "Retrieval simulation", ["Keyword topic match", "Rank fictional fixtures"], "S")
    node(drawing, 352, 166, "Source review", ["Inspect / decide / undo", "Select / Exclude / Not sure"])
    node(drawing, 182, 166, "Review gate", ["All sources decided?", "Not sure = reviewed"])
    node(drawing, 12, 166, "Selected context", ["input_ids / input_passages", "No excluded or unsure"])
    node(drawing, 12, 77, "Scripted synthesis", ["Authored suitability", "Scripted findings / limits"], "S")
    node(drawing, 182, 77, "Structured result", ["Findings / disagreement", "Or no supported answer"])
    node(drawing, 352, 77, "Browser output", ["Summary / no-match state", "Citations open passages"])

    arrow(drawing, [(156, 287), (182, 287)])
    arrow(drawing, [(326, 287), (352, 287)])
    arrow(drawing, [(414, 257), (414, 226)])
    arrow(drawing, [(435, 226), (435, 257)])
    label(drawing, 442, 238, "More refs", 8.3)
    arrow(drawing, [(352, 189), (326, 189)])
    arrow(drawing, [(326, 210), (352, 210)])
    label(drawing, 332, 216, "No", 8.0)
    arrow(drawing, [(182, 189), (156, 189)])
    label(drawing, 161, 196, "Yes", 8.0)
    arrow(drawing, [(84, 166), (84, 137)])
    label(drawing, 97, 149, "Permitted input", 8.2)
    arrow(drawing, [(156, 107), (182, 107)])
    arrow(drawing, [(326, 107), (352, 107)])
    arrow(drawing, [(496, 286), (510, 286), (510, 148), (424, 148), (424, 137)])
    label(drawing, 446, 153, "No matches", 8.1)
    arrow(drawing, [(496, 105), (518, 105), (518, 338), (84, 338), (84, 317)], True)
    label(drawing, 193, 342, "Change question / Start again", 9.0)
    label(drawing, 12, 57, "Changed evidence: clear the previous summary [I]", 9.1)
    node(drawing, 12, 7, "Real retrieval and model integration", [], "P", width=484, height=36)
    label(drawing, 265, 19, "Independent checks and user evaluation", 9.1)
    return drawing


def storyboard_panel(drawing, x, y, title, lines):
    width, height = 118, 136
    drawing.add(Rect(x, y, width, height, rx=4, ry=4, fillColor=colors.white,
                     strokeColor=colors.HexColor("#AEBAB1"), strokeWidth=0.7))
    label(drawing, x + 8, y + height - 17, title, 10.0, True)
    drawing.add(Line(x + 8, y + height - 25, x + width - 8, y + height - 25,
                     strokeColor=colors.HexColor("#E0E6E1"), strokeWidth=0.6))
    for index, line in enumerate(lines):
        role = line in {"USER", "SYSTEM"}
        label(drawing, x + 8, y + height - 41 - index * 10.6, line,
              8.4 if role else 9.1, role, GREEN if role else INK)


def storyboards():
    drawing = Drawing(520, 610)
    cases = [
        ("A  Review sources and extend the evidence", [
            ("1 Ask", ["USER", "Sleep-diary question", "Find references", "SYSTEM", "D1 D2 D3 returned"]),
            ("2 Review", ["USER", "Read D1", "D1 Select", "D2 Exclude", "D3 Not sure", "SYSTEM", "3 of 3 reviewed"]),
            ("3 Add sources", ["USER", "Add more references", "SYSTEM", "D4 D5 unreviewed", "D1 choice saved", "Generation locked"]),
            ("4 Summarise", ["USER", "D4 Select D5 Exclude", "Generate summary", "SYSTEM", "D1 D4 findings", "Citation opens source"]),
        ]),
        ("B  See disagreement and correct the selection", [
            ("1 Ask", ["USER", "Wind-Down calmness", "Find references", "SYSTEM", "C1 C2 C3 returned"]),
            ("2 Review", ["USER", "C1 C2 Select", "C3 Exclude", "Generate summary"]),
            ("3 Compare", ["SYSTEM", "Sources disagree", "C1 Greater calmness", "C2 No change", "No overall effect"]),
            ("4 Correct", ["USER", "Reopen C2", "Choose Not sure", "SYSTEM", "Old summary cleared", "USER", "Generate again", "SYSTEM", "C1-only summary"]),
        ]),
        ("C  Receive no supported answer and restart", [
            ("1 Ask", ["USER", "Wearable sleep scores", "For schoolchildren", "Find references"]),
            ("2 Review", ["USER", "I1 Select adult study", "I2 Exclude", "I3 Not sure", "Generate summary"]),
            ("3 Check limits", ["SYSTEM", "Insufficient evidence", "No supported answer", "I1 supplies no finding", "Scripted label [S]"]),
            ("4 Recover", ["USER", "Undo last exclusion", "SYSTEM", "I2 unreviewed", "I1 choice saved", "Old output cleared", "Generation locked"]),
        ]),
    ]
    for index, (heading, panels) in enumerate(cases):
        baseline = 434 - index * 192
        label(drawing, 12, baseline + 151, heading, 11.0, True)
        for col, (title, lines) in enumerate(panels):
            x = 12 + col * 130
            storyboard_panel(drawing, x, baseline, title, lines)
            if col < 3:
                arrow(drawing, [(x + 120, baseline + 67), (x + 128, baseline + 67)])
    label(drawing, 12, 24, "USER actions and SYSTEM responses replay the implemented prototype.", 9.0)
    label(drawing, 12, 10, "All evidence is fictional. Scripted inference is simulated; no participant study is shown.", 9.0)
    return drawing



def scaled(drawing):
    factor = WIDTH / drawing.width
    result = copy.deepcopy(drawing)
    result.scale(factor, factor)
    result.width = WIDTH
    result.height = drawing.height * factor
    return result


def escape_body(value):
    return escape(str(value)).replace("\n", "<br/>")


def make_styles():
    return {
        "body": ParagraphStyle("Body", fontName="RF", fontSize=11.0, leading=14.0, textColor=INK, spaceAfter=5.5),
        "abstract": ParagraphStyle("AbstractBody", fontName="RF", fontSize=10.8, leading=14.0, textColor=INK, spaceAfter=6),
        "title": ParagraphStyle("Title", fontName="RF-Bold", fontSize=25, leading=29, textColor=INK, spaceAfter=5),
        "subtitle": ParagraphStyle("Subtitle", fontName="RF-Bold", fontSize=15, leading=18, textColor=INK, spaceAfter=8),
        "heading": ParagraphStyle("Heading", fontName="RF-Bold", fontSize=13, leading=16, textColor=INK, spaceBefore=8, spaceAfter=7, keepWithNext=True),
        "meta": ParagraphStyle("Meta", fontName="RF", fontSize=9.5, leading=12.1, textColor=INK, spaceAfter=3),
        "count": ParagraphStyle("Count", fontName="RF-Bold", fontSize=10.3, leading=13.5, textColor=INK, spaceAfter=3),
        "note": ParagraphStyle("Note", fontName="RF", fontSize=9.1, leading=11.7, textColor=MUTED, spaceAfter=6, splitLongWords=True),
        "ref": ParagraphStyle("Reference", fontName="RF", fontSize=9.15, leading=11.55, textColor=INK, spaceAfter=5),
        "caption": ParagraphStyle("Caption", fontName="RF", fontSize=9.3, leading=12.0, textColor=MUTED, spaceBefore=4, spaceAfter=7),
        "panel": ParagraphStyle("PanelLabel", fontName="RF-Bold", fontSize=10, leading=13, textColor=INK, spaceBefore=7, spaceAfter=5),
    }


def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("RF", 8.5)
    canvas.setFillColor(MUTED)
    canvas.drawString(48, 25, "Reference First")
    canvas.drawRightString(PAGE_W - 48, 25, str(doc.page))
    canvas.restoreState()


def paragraphs(flow, values, styles, style="body"):
    for value in values:
        flow.append(Paragraph(escape_body(value), styles[style]))


def section(flow, data, styles):
    flow.append(Paragraph(escape(data["heading"]), styles["heading"]))
    paragraphs(flow, data["paragraphs"], styles)


def validate_counts(content):
    counted = [content["title"], content["course"], content["counting_note"]]
    counted += [text for item in content["sections"] for text in [item["heading"], *item["paragraphs"]]]
    metadata_words = content.get("word_counts", {}).get("metadata_words", 15)
    main = len(" ".join(counted).split()) + metadata_words
    abstract = len(("Abstract " + content["abstract"]).split())
    counts = {"main": main, "abstract": abstract, "total": main + abstract,
              "method": content["counting_note"], "metadata_words": metadata_words}
    if main > 1100 or abstract > 300 or main + abstract > 1400:
        raise RuntimeError(f"Report word limit exceeded: {counts}")
    if content["word_counts"] != counts:
        raise RuntimeError(f"Report source word counts are stale; expected {counts}")
    if counts["total"] >= 1300:
        warnings.warn("Combined counted prose is at least 1,300 words; aim below that threshold.")
    return counts


def screenshot_info(panel):
    path = (DOCS / panel["file"]).resolve()
    path.relative_to(DOCS.resolve())
    if not path.is_file():
        raise FileNotFoundError(f"Screenshot missing: {path}")
    reader = ImageReader(str(path))
    source_width, source_height = reader.getSize()
    raw = panel.get("crop", [0, 0, source_width, source_height])
    if len(raw) != 4:
        raise ValueError("Screenshot crop must be [x, y, width, height].")
    x, y, width, height = [float(value) for value in raw]
    if min(x, y) < 0 or min(width, height) <= 0:
        raise ValueError(f"Invalid screenshot crop for {path.name}: {raw}")
    if x + width > source_width + 1 or y + height > source_height + 1:
        raise ValueError(f"Screenshot crop exceeds source bounds for {path.name}: {raw}")
    return {"path": path, "reader": reader, "source_width": source_width,
            "source_height": source_height, "x": x, "y": y, "width": width, "height": height}


class CroppedScreenshot(Flowable):
    """Clip an original screenshot in PDF coordinates; the source image is never edited."""

    def __init__(self, panel, max_height=270):
        super().__init__()
        self.panel = panel
        self.info = screenshot_info(panel)
        self.requested_width = min(float(panel.get("width", WIDTH)), WIDTH)
        self.max_height = float(panel.get("max_height", max_height))
        self.hAlign = "CENTER"
        self._set_size(self.requested_width)

    def _set_size(self, available_width):
        data = self.info
        self.scale_factor = min(available_width / data["width"], self.max_height / data["height"])
        self.width = data["width"] * self.scale_factor
        self.height = data["height"] * self.scale_factor

    def wrap(self, available_width, available_height):
        self._set_size(min(self.requested_width, available_width))
        return self.width, self.height

    def draw(self):
        data, canvas, factor = self.info, self.canv, self.scale_factor
        canvas.saveState()
        clip = canvas.beginPath()
        clip.rect(0, 0, self.width, self.height)
        canvas.clipPath(clip, stroke=0, fill=0)
        image_bottom = -(data["source_height"] - data["y"] - data["height"]) * factor
        canvas.drawImage(data["reader"], -data["x"] * factor, image_bottom,
                         width=data["source_width"] * factor,
                         height=data["source_height"] * factor, mask="auto")
        canvas.restoreState()
        canvas.saveState()
        canvas.setStrokeColor(colors.HexColor("#BCC9BF"))
        canvas.setLineWidth(0.55)
        canvas.rect(0, 0, self.width, self.height, stroke=1, fill=0)
        for marker in self.panel.get("markers", []):
            mx = (float(marker["x"]) - data["x"]) * factor
            my = (data["height"] - (float(marker["y"]) - data["y"])) * factor
            if not (0 <= mx <= self.width and 0 <= my <= self.height):
                warnings.warn(f"Marker {marker['n']} is outside crop in {self.panel['file']}.")
                continue
            canvas.setFillColor(colors.HexColor("#A45712"))
            canvas.setStrokeColor(colors.white)
            canvas.setLineWidth(1.0)
            canvas.circle(mx, my, 8.3, stroke=1, fill=1)
            canvas.setFillColor(colors.white)
            canvas.setFont("RF-Bold", 9.2)
            canvas.drawCentredString(mx, my - 3.1, str(marker["n"]))
        canvas.restoreState()


def screenshot_html(panel):
    data = screenshot_info(panel)
    src = escape(panel["file"], quote=True)
    crop_width, crop_height = data["width"], data["height"]
    css = (
        "position:relative;overflow:hidden;width:100%;border:1px solid #bcc9bf;background:white;"
        f"aspect-ratio:{crop_width:g}/{crop_height:g};"
        f"max-width:{float(panel.get('html_width', 780)):g}px;"
    )
    image_css = (
        "position:absolute;height:auto;max-width:none;display:block;"
        f"width:{data['source_width'] / crop_width * 100:.6f}%;"
        f"left:{-data['x'] / crop_width * 100:.6f}%;"
        f"top:{-data['y'] / crop_height * 100:.6f}%;"
    )
    result = [f"<figure class='screenshot-panel' style='margin:16px 0'><figcaption style='font:600 14px/1.5 Arial,sans-serif;margin-bottom:7px'>{escape(panel.get('label', 'Prototype screenshot'))}</figcaption>",
              f"<div class='screenshot-crop' style='{css}'><img src='{src}' style='{image_css}' alt='{escape(panel.get('label', 'Prototype screenshot'), quote=True)}'>"]
    for marker in panel.get("markers", []):
        left = (float(marker["x"]) - data["x"]) / crop_width * 100
        top = (float(marker["y"]) - data["y"]) / crop_height * 100
        if 0 <= left <= 100 and 0 <= top <= 100:
            marker_css = ("position:absolute;transform:translate(-50%,-50%);display:grid;place-items:center;"
                          "width:23px;height:23px;border:2px solid white;border-radius:50%;"
                          "background:#a45712;color:white;font:bold 13px Arial,sans-serif;")
            result.append(f"<span class='screenshot-marker' style='{marker_css}left:{left:.5f}%;top:{top:.5f}%'>{escape(str(marker['n']))}</span>")
    result += ["</div></figure>"]
    return "\n".join(result)


def repository_values(content):
    repo = content["repository"]
    return {
        "url": repo.get("url", ""),
        "readme": repo.get("readme", ""),
        "release": repo.get("release", repo.get("snapshot", "")),
        "source_manifest_sha256": repo.get("source_manifest_sha256", ""),
        "published_commit": repo.get("published_commit", repo.get("commit", "")),
        "published_commit_url": repo.get("published_commit_url", repo.get("commit_url", "")),
        "publication_status": repo.get("publication_status", repo.get("commit_status", "")),
        "archive_sha256": repo.get("archive_sha256", ""),
    }


EVIDENCE_FILES = [
    ("Development evidence", "development_evidence.md"),
    ("Recorded verification results", "verification_results.txt"),
    ("Selected context example", "context_example.json"),
]


def evidence_links():
    return [(label_text, relative) for label_text, relative in EVIDENCE_FILES if (DOCS / relative).is_file()]


def write_sources(content, counts, architecture, replay):
    renderSVG.drawToFile(architecture, str(DOCS / "system_diagram.svg"))
    renderSVG.drawToFile(replay, str(DOCS / "storyboards.svg"))
    figure_dir = ROOT / "tmp" / "report_figures"
    figure_dir.mkdir(parents=True, exist_ok=True)
    renderPDF.drawToFile(architecture, str(figure_dir / "system_diagram.pdf"))
    renderPDF.drawToFile(replay, str(figure_dir / "storyboards.pdf"))
    (DOCS / "word_counts.json").write_text(json.dumps(counts, indent=2) + "\n", encoding="utf-8")

    repo = repository_values(content)
    date = content.get("date", "24 November 2026")
    body = ["# " + content["title"], content["course"], date,
            f"Total report word count {counts['total']}",
            f"Main report {counts['main']} words    Abstract {counts['abstract']} words",
            content["counting_note"], "## Abstract", content["abstract"]]
    for index, item in enumerate(content["sections"]):
        body += ["## " + item["heading"], *item["paragraphs"]]
        if index == 2:
            body += ["![System diagram](system_diagram.svg)", content["figure1_caption"]]
    for case in content.get("screenshot_cases", []):
        body += ["## " + case["heading"], case.get("steps", "")]
        for panel in case["panels"]:
            body.append(screenshot_html(panel))
        body.append(case.get("caption", ""))
    body += ["## Repository and development evidence",
             f"[Repository]({repo['url']})", f"[README and development record]({repo['readme']})"]
    body += [f"[{title}]({relative})" for title, relative in evidence_links()]
    body += ["[Schematic interaction overview](storyboards.svg)", "## References"]
    for ref in content["references"]:
        body.append(f"[{ref['id']}] {ref['text']}" + (" " + ref["url"] if ref.get("url") else ""))
    body += ["## Acknowledgements", content["acknowledgement"]]
    (DOCS / "report.md").write_text("\n\n".join(body) + "\n", encoding="utf-8")

    html = ["<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>",
            "<title>Reference First report</title>",
            "<style>body{max-width:820px;margin:35px auto;font:16px/1.65 Georgia,serif;color:#111;padding:0 24px}h1,h2,h3{font-family:Arial,sans-serif;color:#000}h1{font-size:30px}h2{font-size:21px;margin-top:25px}p{margin:9px 0}svg{width:100%;height:auto}a{color:#174b8a}.small{font-size:13px;color:#53615a}.screenshot-case{break-before:page}.screenshot-panel{margin:16px 0}.screenshot-panel figcaption{font:600 14px/1.5 Arial,sans-serif;margin-bottom:7px}.screenshot-crop{position:relative;overflow:hidden;width:100%;border:1px solid #bcc9bf;background:white}.screenshot-crop img{position:absolute;height:auto;max-width:none;display:block}.screenshot-marker{position:absolute;transform:translate(-50%,-50%);display:grid;place-items:center;width:23px;height:23px;border:2px solid white;border-radius:50%;background:#a45712;color:white;font:bold 13px Arial,sans-serif}@media print{body{margin:0;max-width:none}h2{break-after:avoid}.screenshot-panel{break-inside:avoid}svg{max-height:80vh}}</style></head><body>",
            f"<h1>{escape(content['title'])}</h1><p>{escape(content['course'])}</p><p>{escape(date)}</p>",
            f"<p><strong>Total report word count {counts['total']}</strong><br>Main report {counts['main']} words · Abstract {counts['abstract']} words</p>",
            "<p class='small'>" + escape(content["counting_note"]) + "</p><h2>Abstract</h2>"]
    html += ["<p>" + escape_body(p) + "</p>" for p in content["abstract"].split("\n\n")]
    for index, item in enumerate(content["sections"]):
        html.append("<h2>" + escape(item["heading"]) + "</h2>")
        html += ["<p>" + escape_body(p) + "</p>" for p in item["paragraphs"]]
        if index == 2:
            svg = (DOCS / "system_diagram.svg").read_text(encoding="utf-8")
            html += [svg[svg.index("<svg"):], "<p class='small'>" + escape(content["figure1_caption"]) + "</p>"]
    for case in content.get("screenshot_cases", []):
        html += ["<section class='screenshot-case'><h2>" + escape(case["heading"]) + "</h2>",
                 "<p class='small'>" + escape(case.get("steps", "")) + "</p>"]
        html += [screenshot_html(panel) for panel in case["panels"]]
        html += ["<p class='small'>" + escape(case.get("caption", "")) + "</p></section>"]
    html += ["<h2>Repository and development evidence</h2>",
             f"<p><a href='{escape(repo['url'], quote=True)}'>Repository</a> · <a href='{escape(repo['readme'], quote=True)}'>README and development record</a></p>"]
    html += [f"<p><a href='{escape(relative, quote=True)}'>{escape(title)}</a></p>" for title, relative in evidence_links()]
    html += ["<p><a href='storyboards.svg'>Schematic interaction overview</a></p>", "<h2>References</h2>"]
    for ref in content["references"]:
        value = f"<p>[{ref['id']}] {escape(ref['text'])}"
        if ref.get("url"):
            value += f" <a href='{escape(ref['url'], quote=True)}'>{escape(ref['url'])}</a>"
        html.append(value + "</p>")
    html += ["<h2>Acknowledgements</h2>", "<p>" + escape(content["acknowledgement"]) + "</p></body></html>"]
    (DOCS / "report.html").write_text("\n".join(html), encoding="utf-8")


def add_repository_evidence(flow, content, styles):
    repo = repository_values(content)
    flow.append(Paragraph("Repository and development evidence", styles["heading"]))
    for title, target in [("Repository", repo["url"]), ("README and development record", repo["readme"])]:
        if target:
            flow.append(Paragraph(f"<b>{escape(title)}</b> <link href='{escape(target, quote=True)}' color='#174B8A'>{escape(target)}</link>", styles["meta"]))
    local = []
    for title, relative in evidence_links():
        target = posixpath.normpath("../../docs/" + relative)
        local.append(f"<link href='{escape(target, quote=True)}' color='#174B8A'>{escape(title)}</link>")
    local.append("<link href='../../README.md#development-record-and-verification' color='#174B8A'>Local README development record</link>")
    if local:
        flow.append(Paragraph("Evidence files: " + " · ".join(local), styles["meta"]))


def add_screenshot_case(flow, case, styles):
    flow.append(Paragraph(escape(case["heading"]), styles["heading"]))
    if case.get("steps"):
        flow.append(Paragraph(escape_body(case["steps"]), styles["caption"]))
    panels = case.get("panels", [])
    if not panels:
        raise ValueError(f"Screenshot case has no panels: {case['heading']}")
    max_height = min(270, 570 / len(panels))
    for panel in panels:
        block = [Paragraph(escape(panel.get("label", "Prototype screenshot")), styles["panel"]),
                 CroppedScreenshot(panel, max_height=max_height), Spacer(1, 7)]
        flow.append(KeepTogether(block))
    if case.get("caption"):
        flow.append(Paragraph(escape_body(case["caption"]), styles["caption"]))


def build():
    DOCS.mkdir(exist_ok=True)
    OUT.mkdir(parents=True, exist_ok=True)
    register_fonts()
    content = json.loads(SOURCE.read_text(encoding="utf-8"))
    counts = validate_counts(content)
    if len(content["sections"]) != 6:
        raise RuntimeError("The improved report requires six ordered main sections.")
    architecture, replay = system_diagram(), storyboards()
    write_sources(content, counts, architecture, replay)
    styles = make_styles()
    flow = [
        Paragraph(escape(content["course"]), styles["meta"]),
        Paragraph("Reference First", styles["title"]),
        Paragraph("Project and Development Report", styles["subtitle"]),
        Paragraph(escape(content.get("date", "24 November 2026")), styles["meta"]),
        Paragraph(f"Total report word count {counts['total']}", styles["count"]),
        Paragraph(f"Main report {counts['main']} words&nbsp;&nbsp;&nbsp; Abstract {counts['abstract']} words", styles["meta"]),
        Paragraph(escape(content["counting_note"]), styles["note"]),
        Paragraph("Abstract", styles["heading"]),
    ]
    paragraphs(flow, content["abstract"].split("\n\n"), styles, "abstract")
    section(flow, content["sections"][0], styles)
    flow.append(PageBreak())
    section(flow, content["sections"][1], styles)
    flow.append(PageBreak())
    section(flow, content["sections"][2], styles)
    flow.append(scaled(architecture))
    flow.append(Paragraph(escape(content["figure1_caption"]), styles["caption"]))
    flow.append(PageBreak())
    for item in content["sections"][3:]:
        section(flow, item, styles)
    for case in content.get("screenshot_cases", []):
        flow.append(PageBreak())
        add_screenshot_case(flow, case, styles)
    flow.append(PageBreak())
    add_repository_evidence(flow, content, styles)
    flow.append(Paragraph("References", styles["heading"]))
    for ref in content["references"]:
        text = f"[{ref['id']}] {escape(ref['text'])}"
        if ref.get("url"):
            target = escape(ref["url"], quote=True)
            text += f" <link href='{target}' color='#174B8A'>{escape(ref['url'])}</link>"
        flow.append(Paragraph(text, styles["ref"]))
    flow.append(Paragraph("Acknowledgements", styles["heading"]))
    flow.append(Paragraph(escape(content["acknowledgement"]), styles["ref"]))
    path = OUT / "Reference_First_A2_Report.pdf"
    document = SimpleDocTemplate(str(path), pagesize=A4, leftMargin=48, rightMargin=48,
                                 topMargin=40, bottomMargin=43, title=content["title"],
                                 author="", subject="Intelligent Interactive Systems Assignment 2")
    document.build(flow, onFirstPage=footer, onLaterPages=footer)
    print(f"Report: {path}")
    print(json.dumps(counts))
    try:
        import pypdf
        print(f"PDF pages: {len(pypdf.PdfReader(path).pages)}")
    except ImportError:
        pass


if __name__ == "__main__":
    build()

