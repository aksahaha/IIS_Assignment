"""Compatibility entry point for the complete prototype and report archive.

Prepare source identity, build the report, then run this entry point or
package_submission.py. The current ZIP includes report, tests and all folders.
"""
from package_submission import package

if __name__ == "__main__":
    package()
