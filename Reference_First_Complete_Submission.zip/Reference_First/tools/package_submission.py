"""Prepare source identity and package the complete Reference First submission."""

import argparse
import hashlib
import json
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RELEASE = "rf-review-recovery-2026-11-24"
PACKAGE = "Reference_First"
CODE_FILES = (
    "engine.py", "serve_prototype.py", "fixtures.json", "open_prototype.cmd",
    "web/index.html", "web/styles.css", "web/prototype.js",
    "tests/test_engine.py", "tests/test_web.py", "app.py", "run_windows.cmd",
    "tools/build_report.py", "tools/package_report.py",
    "tools/package_prototype.py", "tools/package_submission.py",
)
DOC_FILES = (
    "README.md", "VERSION.txt", "SOURCE_MANIFEST.sha256", "GITHUB_UPLOAD.txt",
    "output/pdf/Reference_First_A2_Report.pdf", "docs/report.md",
    "docs/report.html", "docs/report_content.json", "docs/word_counts.json",
    "docs/system_diagram.svg", "docs/storyboards.svg",
    "docs/report_requirements_check.md", "docs/development_evidence.md",
    "docs/verification_results.txt", "docs/context_example.json",
    "docs/publication_status.md", "docs/screenshots/index.json",
    "docs/screenshots/browser_checks.json",
)

START_HERE = """REFERENCE FIRST COMPLETE PROJECT

1. Extract this entire ZIP. Keep all folders together.
2. Open output/pdf/Reference_First_A2_Report.pdf for the report.
3. On Windows, double-click open_prototype.cmd to run the browser prototype.
4. Keep its terminal open; press Ctrl+C there to stop.

Requires Python 3.10 or newer and a modern browser. The prototype uses only
the Python standard library and does not need packages, accounts or keys.
If needed, run: python serve_prototype.py --port 8766

Try: Can a sleep diary help adults describe their sleep routine?
Read D1 and Select it; Exclude D2; mark D3 Not sure. Selected rows reopen
on click. Excluded cards disappear. Undo last exclusion restores the last
excluded source for review while keeping the other choices.
Review added references before generating. Citations open original passages.

All references and summaries are fictional simulations, not live search/AI.
README.md explains scope, setup, development evidence and AI assistance.
GITHUB_UPLOAD.txt explains how to preserve folders when uploading.
VERSION.txt identifies the packaged release. SOURCE_MANIFEST.sha256 identifies
the code; MANIFEST.sha256 identifies all archive contents except itself.

The older app.py desktop demonstration is retained as development source;
open_prototype.cmd launches the current browser version used by the report.
"""

UPLOAD = """UPDATING THE PUBLIC REPOSITORY

Repository: https://github.com/aksahaha/IIS_Assignment
README: https://github.com/aksahaha/IIS_Assignment#readme

Extract this ZIP, open the Reference_First folder, and upload its complete
contents to the repository. Preserve web/, tests/, tools/, docs/ and output/.
Do not upload only the loose Python files or only the ZIP itself if reviewers
are expected to inspect and run the source directly from the repository.

After uploading, check that these paths are visible in GitHub:
  web/index.html
  web/prototype.js
  web/styles.css
  tests/test_engine.py
  tests/test_web.py
  output/pdf/Reference_First_A2_Report.pdf
  docs/development_evidence.md

The report includes the repository and README links. Check that the public
repository contains the complete source and the matching report PDF.
"""


def digest(data):
    return hashlib.sha256(data).hexdigest()


def prepare():
    manifest = "".join(
        f"{digest((ROOT / name).read_bytes())}  {name}\n"
        for name in sorted(CODE_FILES)
    )
    (ROOT / "SOURCE_MANIFEST.sha256").write_text(manifest, encoding="utf-8", newline="\n")
    (ROOT / "VERSION.txt").write_text(
        f"Release: {RELEASE}\n"
        "Status: packaged local release; publication is recorded separately\n"
        "Current browser prototype plus report, tests and editable evidence\n"
        "Source identity: SOURCE_MANIFEST.sha256 (code, fixtures and build tools)\n"
        "Full archive identity: MANIFEST.sha256 and external ZIP checksum\n",
        encoding="utf-8", newline="\n",
    )
    (ROOT / "GITHUB_UPLOAD.txt").write_text(UPLOAD, encoding="utf-8", newline="\n")
    print(json.dumps({"release": RELEASE, "source_manifest_sha256": digest(manifest.encode())}))


def package():
    names = [*CODE_FILES, *DOC_FILES]
    names += [str(path.relative_to(ROOT)).replace("\\", "/")
              for path in sorted((ROOT / "docs" / "screenshots").glob("*.jpg"))]
    contents = {name: (ROOT / name).read_bytes() for name in names}
    expected_source = "".join(f"{digest(contents[name])}  {name}\n" for name in sorted(CODE_FILES))
    if contents["SOURCE_MANIFEST.sha256"].decode() != expected_source:
        raise RuntimeError("Source changed after preparation; rerun --prepare and rebuild the report")
    report = json.loads(contents["docs/report_content.json"])
    if report["repository"]["source_manifest_sha256"] != digest(contents["SOURCE_MANIFEST.sha256"]):
        raise RuntimeError("Report does not identify the current source manifest")
    contents["START_HERE.txt"] = START_HERE.encode()
    contents["MANIFEST.sha256"] = "".join(
        f"{digest(data)}  {name}\n" for name, data in sorted(contents.items())
    ).encode()
    output = ROOT.parent / "downloads" / "Reference_First_Complete_Submission.zip"
    output.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(contents.items()):
            archive.writestr(f"{PACKAGE}/{name}", data)
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == {f"{PACKAGE}/{name}" for name in contents}
        for name, data in contents.items():
            assert archive.read(f"{PACKAGE}/{name}") == data, name
    checksum = digest(output.read_bytes())
    output.with_suffix(".zip.sha256").write_text(f"{checksum}  {output.name}\n", encoding="utf-8")
    print(json.dumps({"file": str(output), "files": len(contents), "bytes": output.stat().st_size,
                      "sha256": checksum, "verified": True}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepare", action="store_true", help="Write source identity before report generation")
    arguments = parser.parse_args()
    if arguments.prepare:
        prepare()
    else:
        package()
