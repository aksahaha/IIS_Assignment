"""Package the report and editable evidence while preserving working relative links."""

import hashlib
import json
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BUNDLE = "Reference_First_A2_Report"
REQUIRED = (
    "output/pdf/Reference_First_A2_Report.pdf",
    "docs/report.md",
    "docs/report.html",
    "docs/report_content.json",
    "docs/system_diagram.svg",
    "docs/storyboards.svg",
    "docs/word_counts.json",
    "docs/report_requirements_check.md",
    "docs/development_evidence.md",
    "docs/verification_results.txt",
    "docs/context_example.json",
    "README.md",
    "tools/build_report.py",
    "tools/package_report.py",
)
OPTIONAL = ("SOURCE_MANIFEST.sha256", "VERSION.txt", "GITHUB_UPLOAD.txt",
            "docs/publication_status.md", "docs/screenshots/index.json",
            "docs/screenshots/browser_checks.json")


def instructions(content, counts, page_count):
    repo = content.get("repository", {})
    pages = f"{page_count} pages" if page_count is not None else "PDF"
    return f"""REFERENCE FIRST ASSIGNMENT 2 REPORT

Extract the entire ZIP before opening the report.
Open output/pdf/Reference_First_A2_Report.pdf ({pages}).

Main report: {counts['main']} words.
Abstract: {counts['abstract']} words.
Total counted prose: {counts['total']} words.

Project repository: {repo['url']}
Project README: {repo['readme']}

CONTENTS
- output/pdf: the report for reading and submission.
- docs/report.html: editable HTML with the same prose, figures and screenshots.
- docs/report.md: editable Markdown; its screenshot crops use inline HTML.
- docs/report_content.json: authoring content and figure/crop configuration.
- docs/screenshots: original prototype screenshots; images were not edited.
- docs/system_diagram.svg and storyboards.svg: editable vector figures.
- docs/word_counts.json: word totals and the declared counting method.
- docs/development_evidence.md: development choices, checks and version evidence.
- docs/verification_results.txt: recorded test output.
- docs/context_example.json: an inspectable selected-input/output example.
- docs/report_requirements_check.md: preparation checklist, outside report prose.
- README.md: the project README supplied as evidence.
- tools: scripts used to rebuild this report source bundle.

Relative paths are preserved so screenshot and evidence links remain usable.
The project prototype is supplied separately; the README launch commands need
that prototype source. This report bundle does not duplicate every runtime file.
Source-manifest and submission-version files are included when available.

REBUILD
Run tools/build_report.py from the complete project after editing the JSON.
It requires Python, ReportLab and Windows Calibri fonts. It exports PDF, HTML,
Markdown and figures. New screenshot panels use crop coordinates and numbered
overlays; the source images remain unchanged. Check word totals, then visually
review every rendered PDF page after changes.

Submit the report according to the assignment brief. The editable source bundle
and verification artifacts support inspection; they are not extra report prose.
"""


def main():
    content = json.loads((ROOT / "docs/report_content.json").read_text(encoding="utf-8"))
    counts = json.loads((ROOT / "docs/word_counts.json").read_text(encoding="utf-8"))
    files = set(REQUIRED)
    files.update(path for path in OPTIONAL if (ROOT / path).is_file())
    for case in content.get("screenshot_cases", []):
        for panel in case["panels"]:
            relative = Path("docs") / panel["file"]
            resolved = (ROOT / relative).resolve()
            resolved.relative_to((ROOT / "docs").resolve())
            files.add(relative.as_posix())
    missing = [path for path in sorted(files) if not (ROOT / path).is_file()]
    if missing:
        raise FileNotFoundError("Report bundle files missing: " + ", ".join(missing))
    contents = {name: (ROOT / name).read_bytes() for name in sorted(files)}
    page_count = None
    try:
        import pypdf
        page_count = len(pypdf.PdfReader(ROOT / "output/pdf/Reference_First_A2_Report.pdf").pages)
    except ImportError:
        pass
    contents["READ_FIRST.txt"] = instructions(content, counts, page_count).encode("utf-8")
    contents["PACKAGE_MANIFEST.sha256"] = "".join(
        f"{hashlib.sha256(data).hexdigest()}  {name}\n"
        for name, data in sorted(contents.items())
    ).encode("utf-8")
    destination = ROOT.parent / "downloads/Reference_First_A2_Report.zip"
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in contents.items():
            archive.writestr(f"{BUNDLE}/{name}", data)
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("Report ZIP integrity check failed.")
        expected = {f"{BUNDLE}/{name}" for name in contents}
        if set(archive.namelist()) != expected:
            raise RuntimeError("Report ZIP contents differ from the selected files.")
        for name, data in contents.items():
            if archive.read(f"{BUNDLE}/{name}") != data:
                raise RuntimeError(f"Packaged file differs from its source: {name}")
    print(f"Created and verified {destination}")
    print(f"{len(contents)} files; {destination.stat().st_size:,} bytes")
    print(f"SHA-256: {hashlib.sha256(destination.read_bytes()).hexdigest()}")


if __name__ == "__main__":
    main()
