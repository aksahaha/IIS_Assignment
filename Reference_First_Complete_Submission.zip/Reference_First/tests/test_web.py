"""HTTP checks for the local browser interface and its human-review boundary."""

import http.client
import json
import tempfile
import threading
import unittest
from pathlib import Path

from serve_prototype import COOKIE_NAME, MAX_BODY_BYTES, PrototypeServer


class BrowserApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.assets = tempfile.TemporaryDirectory()
        cls.web_root = Path(cls.assets.name) / "web"
        cls.web_root.mkdir()
        (cls.web_root / "index.html").write_text("<!doctype html><title>Reference First</title>", encoding="utf-8")
        (Path(cls.assets.name) / "outside.txt").write_text("outside the static root", encoding="utf-8")
        cls.server = PrototypeServer(port=0, web_root=cls.web_root)
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=3)
        cls.assets.cleanup()

    def setUp(self):
        self.cookie = None

    def request(self, path, data=None, method=None, headers=None, remember_cookie=True, raw=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=3)
        request_headers = dict(headers or {})
        if self.cookie:
            request_headers.setdefault("Cookie", self.cookie)
        body = raw if raw is not None else json.dumps(data).encode("utf-8") if data is not None else None
        if body is not None:
            request_headers.setdefault("Content-Type", "application/json")
        connection.request(method or ("POST" if data is not None or raw is not None else "GET"), path, body, request_headers)
        response = connection.getresponse()
        response_headers = dict(response.getheaders())
        content = response.read()
        status = response.status
        connection.close()
        if remember_cookie and "Set-Cookie" in response_headers:
            self.cookie = response_headers["Set-Cookie"].split(";", 1)[0]
        payload = json.loads(content) if response_headers.get("Content-Type", "").startswith("application/json") else content
        return status, payload, response_headers

    def action(self, path, data=None):
        status, payload, _ = self.request(path, {} if data is None else data)
        self.assertEqual(status, 200, payload)
        return payload

    def classify(self, decisions):
        for source_id, choice in decisions.items():
            self.action("/api/decision", {"source_id": source_id, "choice": choice})

    def test_snapshot_and_private_browser_cookie(self):
        status, state, headers = self.request("/api/session")
        self.assertEqual(status, 200)
        self.assertEqual(state["case_id"], "diary")
        self.assertEqual(len(state["cases"]), 3)
        self.assertEqual(state["reviewed"], 0)
        self.assertFalse(state["ready"])
        self.assertIsNone(state["result"])
        self.assertEqual(state["decisions"], {"D1": None, "D2": None, "D3": None})
        self.assertIn(COOKIE_NAME + "=", headers["Set-Cookie"])
        self.assertIn("HttpOnly", headers["Set-Cookie"])
        self.assertIn("SameSite=Strict", headers["Set-Cookie"])
        self.assertEqual(headers["Cache-Control"], "no-store")
        self.assertEqual(state["search_query"], "")
        self.assertEqual(state["available_reference_count"], 3)
        self.assertNotIn("additional_sources", state["case"])
        self.assertFalse(state["question_submitted"])
        self.assertEqual(state["requested_question"], "")
        self.assertEqual(state["retrieval_message"], "")

    def test_relevant_summary_provenance_and_revised_input(self):
        self.classify({"D1": "Select", "D2": "Exclude", "D3": "Uncertain"})
        state = self.action("/api/generate")
        self.assertTrue(state["ready"])
        result = state["result"]
        self.assertEqual(result["status"], "summary")
        self.assertEqual(result["input_ids"], ["D1"])
        self.assertEqual(result["claims"][0]["quote"], state["case"]["sources"][0]["passage"])
        unchanged = self.action("/api/decision", {"source_id": "D1", "choice": "Select"})
        self.assertEqual(unchanged["result"], result)
        revised = self.action("/api/decision", {"source_id": "D1", "choice": "Uncertain"})
        self.assertIsNone(revised["result"])
        self.assertEqual(self.action("/api/generate")["result"]["status"], "insufficient")

    def test_conflict_and_recovery(self):
        self.action("/api/case", {"case_id": "conflict"})
        self.classify({"C1": "Select", "C2": "Select", "C3": "Exclude"})
        self.assertEqual(self.action("/api/generate")["result"]["status"], "conflict")
        revised = self.action("/api/decision", {"source_id": "C2", "choice": "Uncertain"})
        self.assertIsNone(revised["result"])
        result = self.action("/api/generate")["result"]
        self.assertEqual(result["status"], "summary")
        self.assertEqual(result["input_ids"], ["C1"])
        self.assertEqual([claim["source_id"] for claim in result["claims"]], ["C1"])

    def test_insufficient_evidence_stop_and_restart(self):
        self.action("/api/case", {"case_id": "insufficient"})
        self.classify({"I1": "Select", "I2": "Exclude", "I3": "Uncertain"})
        result = self.action("/api/generate")["result"]
        self.assertEqual(result["status"], "insufficient")
        self.assertEqual(result["input_ids"], ["I1"])
        self.assertEqual(result["claims"], [])
        self.assertEqual(result["omitted_selected_ids"], ["I1"])
        stopped = self.action("/api/stop")
        self.assertTrue(stopped["stopped"])
        self.assertFalse(stopped["ready"])
        self.assertIsNone(stopped["result"])
        status, _, _ = self.request("/api/decision", {"source_id": "I1", "choice": "Exclude"})
        self.assertEqual(status, 400)
        restarted = self.action("/api/restart")
        self.assertFalse(restarted["stopped"])
        self.assertEqual(restarted["reviewed"], 0)
        self.assertEqual(restarted["case_id"], "insufficient")

    def test_browser_sessions_are_isolated(self):
        first = self.action("/api/decision", {"source_id": "D1", "choice": "Select"})
        first_cookie = self.cookie
        self.cookie = None
        _, other, _ = self.request("/api/session")
        self.assertEqual(other["reviewed"], 0)
        self.assertNotEqual(self.cookie, first_cookie)
        self.action("/api/case", {"case_id": "conflict"})
        self.cookie = first_cookie
        _, restored, _ = self.request("/api/session")
        self.assertEqual(restored["case_id"], "diary")
        self.assertEqual(restored["decisions"], first["decisions"])

    def test_review_gate_invalid_choices_and_missing_fields(self):
        for path, body in [
            ("/api/generate", {}),
            ("/api/decision", {"source_id": "D1", "choice": "Approve"}),
            ("/api/decision", {"source_id": "missing", "choice": "Select"}),
            ("/api/decision", {"source_id": "D1"}),
            ("/api/decision", {"source_id": [], "choice": "Select"}),
            ("/api/case", {"case_id": "missing"}),
            ("/api/restart", {"unexpected": True}),
        ]:
            with self.subTest(path=path, body=body):
                status, payload, _ = self.request(path, body)
                self.assertEqual(status, 400)
                self.assertIsInstance(payload["error"], str)
                self.assertNotIn("Traceback", payload["error"])

    def test_malformed_or_excessive_body(self):
        for body in [b"{", b"[]", b"\xff", b" " * (MAX_BODY_BYTES + 1)]:
            with self.subTest(body=body[:20]):
                status, payload, _ = self.request("/api/generate", raw=body)
                self.assertEqual(status, 400)
                self.assertIn("error", payload)
        status, _, _ = self.request("/api/generate", raw=b"{}", headers={"Content-Type": "text/plain"})
        self.assertEqual(status, 400)

    def test_origin_validation_does_not_change_state(self):
        self.request("/api/session")
        status, _, _ = self.request("/api/stop", {}, headers={"Origin": "https://example.com"})
        self.assertEqual(status, 403)
        _, state, _ = self.request("/api/session")
        self.assertFalse(state["stopped"])
        status, state, _ = self.request("/api/stop", {}, headers={"Origin": f"http://127.0.0.1:{self.port}"})
        self.assertEqual(status, 200)
        self.assertTrue(state["stopped"])

    def test_untrusted_host_is_rejected(self):
        status, payload, _ = self.request("/api/session", headers={"Host": "example.com"})
        self.assertEqual(status, 403)
        self.assertIn("error", payload)

    def test_static_root_unknown_paths_and_path_traversal(self):
        status, content, headers = self.request("/")
        self.assertEqual(status, 200)
        self.assertIn(b"Reference First", content)
        self.assertIn("text/html", headers["Content-Type"])
        for path in ["/missing.html", "/api/missing", "/../outside.txt", "/%2e%2e/outside.txt", "/%2e%2e%5coutside.txt", "/%00"]:
            with self.subTest(path=path):
                status, payload, _ = self.request(path)
                self.assertEqual(status, 404)
                self.assertIn("error", payload)
                self.assertNotIn("outside the static root", str(payload))
        self.assertEqual(self.request("/api/missing", {})[0], 404)

    def test_more_references_preserve_decisions_clear_output_and_need_review(self):
        self.classify({"D1": "Select", "D2": "Exclude", "D3": "Uncertain"})
        self.action("/api/generate")
        state = self.action("/api/references", {"query": "  adult sleep diary  "})
        self.assertEqual(state["search_query"], "adult sleep diary")
        self.assertEqual(state["available_reference_count"], 1)
        self.assertEqual(len(state["case"]["sources"]), 5)
        self.assertEqual(state["decisions"], {"D1": "Select", "D2": "Exclude", "D3": "Uncertain", "D4": None, "D5": None})
        self.assertFalse(state["ready"])
        self.assertIsNone(state["result"])
        self.assertNotIn("additional_sources", state["case"])
        self.assertEqual(self.request("/api/generate", {})[0], 400)
        self.classify({"D4": "Select", "D5": "Uncertain"})
        result = self.action("/api/generate")["result"]
        self.assertEqual(result["input_ids"], ["D1", "D4"])
        self.assertEqual([claim["source_id"] for claim in result["claims"]], ["D1", "D4"])
        self.assertEqual(result["claims"][1]["quote"], next(source["passage"] for source in state["case"]["sources"] if source["id"] == "D4"))

    def test_reference_queries_ranking_exhaustion_and_validation(self):
        for data in ({"query": ""}, {"query": "  \t"}, {"query": "x" * 201}, {"query": 42}, {}):
            with self.subTest(data=data):
                status, payload, _ = self.request("/api/references", data)
                self.assertEqual(status, 400)
                self.assertIn("error", payload)
        state = self.action("/api/references", {"query": "notebook cover"})
        self.assertEqual([source["id"] for source in state["case"]["sources"]][-2:], ["D5", "D4"])
        state = self.action("/api/references", {"query": "withdrawn"})
        ids = [source["id"] for source in state["case"]["sources"]]
        self.assertEqual(len(ids), 6)
        self.assertEqual(len(ids), len(set(ids)))
        self.assertEqual(state["available_reference_count"], 0)
        self.assertEqual(self.request("/api/references", {"query": "more"})[0], 400)
        _, unchanged, _ = self.request("/api/session")
        self.assertEqual(unchanged, state)

    def test_reference_additions_are_isolated_and_reset_after_stop_or_case_change(self):
        first = self.action("/api/references", {"query": "sleep diary"})
        first_cookie = self.cookie
        self.cookie = None
        _, second, _ = self.request("/api/session")
        self.assertEqual(len(second["case"]["sources"]), 3)
        self.assertEqual(second["available_reference_count"], 3)
        self.assertEqual(second["search_query"], "")
        self.cookie = first_cookie
        _, restored, _ = self.request("/api/session")
        self.assertEqual(restored, first)
        self.action("/api/stop")
        self.assertEqual(self.request("/api/references", {"query": "more"})[0], 400)
        restarted = self.action("/api/restart")
        self.assertEqual(len(restarted["case"]["sources"]), 3)
        self.assertEqual(restarted["available_reference_count"], 3)
        self.assertEqual(restarted["search_query"], "")
        self.action("/api/references", {"query": "diary"})
        switched = self.action("/api/case", {"case_id": "conflict"})
        self.assertEqual(len(switched["case"]["sources"]), 3)
        self.assertEqual(switched["available_reference_count"], 3)
        self.assertEqual(switched["search_query"], "")

    def test_typed_question_endpoint_retrieves_matching_topics_or_no_references(self):
        for question, expected in [("sleep diary", "D"), ("wind-down calmness", "C"), ("wearable sleep scores", "I")]:
            with self.subTest(question=question):
                state = self.action("/api/question", {"question": "  " + question + "  "})
                self.assertTrue(state["question_submitted"])
                self.assertEqual(state["requested_question"], question)
                self.assertEqual(state["case"]["question"], question)
                self.assertTrue(all(source["id"].startswith(expected) for source in state["case"]["sources"]))
                self.assertEqual(len(state["case"]["sources"]), 3)
                self.assertFalse(state["ready"])
        state = self.action("/api/question", {"question": "How do volcanoes form?"})
        self.assertEqual(state["case_id"], "unmatched")
        self.assertEqual(state["case"]["sources"], [])
        self.assertEqual(state["available_reference_count"], 0)
        self.assertFalse(state["ready"])
        self.assertEqual(self.request("/api/generate", {})[0], 400)

    def test_question_validation_preserves_current_review(self):
        state = self.action("/api/question", {"question": "sleep diary"})
        for data in ({}, {"question": ""}, {"question": "  "}, {"question": "x" * 501}, {"question": 42}):
            with self.subTest(data=data):
                status, payload, _ = self.request("/api/question", data)
                self.assertEqual(status, 400)
                self.assertIn("error", payload)
                _, current, _ = self.request("/api/session")
                self.assertEqual(current, state)

    def test_retrieval_additions_keep_question_and_new_question_resets_state(self):
        question = "Do wind-down pilots agree about calmness?"
        self.action("/api/question", {"question": question})
        self.classify({"C1": "Select", "C2": "Select", "C3": "Exclude"})
        self.action("/api/generate")
        state = self.action("/api/references", {"query": "adult calmness"})
        self.assertEqual(state["case"]["question"], question)
        self.assertEqual(state["requested_question"], question)
        self.assertIsNone(state["result"])
        self.assertTrue(all(source["id"].startswith("C") for source in state["case"]["sources"]))
        state = self.action("/api/new-question")
        self.assertFalse(state["question_submitted"])
        self.assertEqual(state["requested_question"], "")
        self.assertEqual(state["retrieval_message"], "")
        self.assertEqual(state["case_id"], "diary")
        self.assertEqual(state["reviewed"], 0)
        self.assertIsNone(state["result"])
        self.assertEqual(state["search_query"], "")
        self.action("/api/question", {"question": question})
        restarted = self.action("/api/restart")
        self.assertFalse(restarted["question_submitted"])

    def test_question_retrieval_does_not_leak_between_browser_sessions(self):
        first = self.action("/api/question", {"question": "relaxation and calmness"})
        first_cookie = self.cookie
        self.cookie = None
        _, second, _ = self.request("/api/session")
        self.assertFalse(second["question_submitted"])
        self.assertEqual(second["requested_question"], "")
        self.assertEqual(second["case_id"], "diary")
        self.cookie = first_cookie
        _, restored, _ = self.request("/api/session")
        self.assertEqual(restored, first)


    def test_undo_endpoint_preserves_choices_invalidates_output_and_regates(self):
        self.action("/api/question", {"question": "sleep diary"})
        self.classify({"D1": "Select", "D2": "Exclude", "D3": "Uncertain"})
        before = self.action("/api/generate")
        self.assertTrue(before["can_undo_exclusion"])
        self.assertEqual(before["last_excluded_source_id"], "D2")
        state = self.action("/api/undo-exclusion")
        self.assertEqual(state["decisions"], {"D1": "Select", "D2": None, "D3": "Uncertain"})
        self.assertEqual(state["requested_question"], "sleep diary")
        self.assertEqual(state["reviewed"], 2)
        self.assertFalse(state["ready"])
        self.assertIsNone(state["result"])
        self.assertFalse(state["can_undo_exclusion"])
        self.assertIsNone(state["last_excluded_source_id"])
        self.assertEqual(self.request("/api/generate", {})[0], 400)
        self.classify({"D2": "Uncertain"})
        self.assertEqual(self.action("/api/generate")["result"]["input_ids"], ["D1"])

    def test_undo_stack_is_isolated_and_repeated_undo_restores_earlier_exclusion(self):
        self.classify({"D1": "Exclude", "D2": "Exclude"})
        first_cookie = self.cookie
        self.cookie = None
        _, other, _ = self.request("/api/session")
        self.assertFalse(other["can_undo_exclusion"])
        self.assertEqual(self.request("/api/undo-exclusion", {})[0], 400)
        self.cookie = first_cookie
        state = self.action("/api/undo-exclusion")
        self.assertEqual(state["last_excluded_source_id"], "D1")
        self.assertIsNone(state["decisions"]["D2"])
        self.assertEqual(state["decisions"]["D1"], "Exclude")
        state = self.action("/api/undo-exclusion")
        self.assertFalse(state["can_undo_exclusion"])
        self.assertIsNone(state["decisions"]["D1"])
        self.assertEqual(self.request("/api/undo-exclusion", {})[0], 400)

    def test_empty_undo_and_new_question_reset_do_not_restore_old_sources(self):
        _, initial, _ = self.request("/api/session")
        self.assertEqual(self.request("/api/undo-exclusion", {})[0], 400)
        _, unchanged, _ = self.request("/api/session")
        self.assertEqual(unchanged, initial)
        self.classify({"D2": "Exclude"})
        reset = self.action("/api/new-question")
        self.assertFalse(reset["can_undo_exclusion"])
        self.assertIsNone(reset["last_excluded_source_id"])
        self.action("/api/question", {"question": "calmness"})
        self.classify({"C1": "Exclude"})
        state = self.action("/api/question", {"question": "wearable sleep scores"})
        self.assertFalse(state["can_undo_exclusion"])
        self.assertEqual(self.request("/api/undo-exclusion", {})[0], 400)

if __name__ == "__main__":
    unittest.main()
