import unittest
from engine import Session, load_cases

class InteractionTests(unittest.TestCase):
    def finish(self,s,choices):
        for sid,choice in zip(s.decisions,choices): s.decide(sid,choice)
        return s.generate()

    def test_review_gate(self):
        s=Session()
        with self.assertRaises(ValueError): s.generate()
        s.decide("D1","Select")
        self.assertFalse(s.ready)
        self.assertEqual(s.reviewed,1)

    def test_normal_summary_and_provenance(self):
        s=Session(); r=self.finish(s,["Select","Exclude","Uncertain"])
        self.assertEqual(r["status"],"summary")
        self.assertEqual(r["input_ids"],["D1"])
        self.assertEqual(r["claims"][0]["quote"],s.source("D1")["passage"])
        self.assertTrue(r["simulated"])

    def test_no_selected_sources(self):
        r=self.finish(Session(),["Exclude","Uncertain","Exclude"])
        self.assertEqual(r["status"],"insufficient")
        self.assertEqual(r["claims"],[])

    def test_selected_does_not_certify_suitability(self):
        r=self.finish(Session(case_id="insufficient"),["Select","Exclude","Uncertain"])
        self.assertEqual(r["status"],"insufficient")
        self.assertEqual(r["input_ids"],["I1"])
        self.assertEqual(r["omitted_selected_ids"],["I1"])

    def test_conflict(self):
        r=self.finish(Session(case_id="conflict"),["Select","Select","Exclude"])
        self.assertEqual(r["status"],"conflict")
        self.assertEqual([c["source_id"] for c in r["claims"]],["C1","C2"])

    def test_no_unselected_conflict(self):
        r=self.finish(Session(case_id="conflict"),["Select","Uncertain","Exclude"])
        self.assertEqual(r["status"],"summary")
        self.assertEqual(r["input_ids"],["C1"])
        self.assertNotIn("C2",str(r))

    def test_reclassification_invalidates_output(self):
        s=Session(); self.finish(s,["Select","Exclude","Exclude"])
        s.decide("D1","Uncertain")
        self.assertIsNone(s.result)
        self.assertEqual(s.generate()["status"],"insufficient")

    def test_case_change_resets_state(self):
        s=Session(); self.finish(s,["Select","Exclude","Exclude"])
        s.change_case("conflict")
        self.assertEqual(s.reviewed,0)
        self.assertIsNone(s.result)
        self.assertFalse(s.ready)

    def test_stop_and_restart(self):
        s=Session(); self.finish(s,["Select","Exclude","Exclude"]); s.stop()
        self.assertIsNone(s.result)
        with self.assertRaises(ValueError): s.generate()
        with self.assertRaises(ValueError): s.decide("D1","Exclude")
        s.change_case("diary"); self.assertFalse(s.stopped)

    def test_invalid_choices_rejected(self):
        s=Session()
        for sid,choice in [("D1","Approved"),("NOPE","Select")]:
            with self.assertRaises(ValueError): s.decide(sid,choice)
        with self.assertRaises(ValueError): s.change_case("other")

    def test_every_case_and_choice_combination_preserves_input_boundary(self):
        from itertools import product
        for case in load_cases():
            for choices in product(("Select","Exclude","Uncertain"),repeat=len(load_cases()[case]["sources"])):
                s=Session(case_id=case); r=self.finish(s,choices)
                expected=[sid for sid,c in s.decisions.items() if c=="Select"]
                self.assertEqual(r["input_ids"],expected)
                self.assertEqual([p["source_id"] for p in r["input_passages"]],expected)
                for claim in r["claims"]:
                    self.assertIn(claim["source_id"],expected)
                    self.assertEqual(claim["quote"],s.source(claim["source_id"])["passage"])

    def test_repeating_a_choice_keeps_current_output(self):
        s=Session(); self.finish(s,["Select","Exclude","Exclude"])
        s.decide("D1","Select")
        self.assertIsNotNone(s.result)

    def test_withdrawn_source_cannot_supply_claim(self):
        r=self.finish(Session(),["Exclude","Exclude","Select"])
        self.assertEqual(r["status"],"insufficient")
        self.assertEqual(r["claims"],[])

    def test_fixture_schema_rejects_missing_fields(self):
        import json, tempfile
        from pathlib import Path
        cases=load_cases(); del cases["diary"]["sources"][0]["passage"]
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)/"invalid.json"; p.write_text(json.dumps(cases),encoding="utf-8")
            with self.assertRaises(ValueError): load_cases(p)

    def test_returned_result_cannot_mutate_session(self):
        s=Session(); r=self.finish(s,["Select","Exclude","Exclude"])
        r["input_ids"].clear(); self.assertEqual(s.result["input_ids"],["D1"])

    def test_added_references_preserve_review_choices_and_relock_generation(self):
        s = Session()
        self.finish(s, ["Select", "Exclude", "Uncertain"])
        previous = s.decisions.copy()
        self.assertEqual(len(s.case["sources"]), 3)
        self.assertEqual(s.available_reference_count, 3)
        added = s.add_references("  adult sleep diary  ")
        self.assertEqual(len(added), 2)
        self.assertEqual(len(s.case["sources"]), 5)
        self.assertEqual(s.available_reference_count, 1)
        self.assertEqual(s.search_query, "adult sleep diary")
        self.assertEqual({sid: s.decisions[sid] for sid in previous}, previous)
        self.assertTrue(all(s.decisions[sid] is None for sid in added))
        self.assertEqual([source["id"] for source in s.selected()], ["D1"])
        self.assertEqual(s.reviewed, 3)
        self.assertIsNone(s.result)
        self.assertFalse(s.ready)
        self.assertNotIn("additional_sources", s.case)
        with self.assertRaises(ValueError):
            s.generate()

    def test_reference_ranking_is_deterministic_and_falls_back_on_catalog_order(self):
        matched = Session()
        self.assertEqual(matched.add_references("notebook cover"), ["D5", "D4"])
        repeated = Session()
        self.assertEqual(repeated.add_references("NOTEBOOK cover"), ["D5", "D4"])
        unmatched = Session()
        self.assertEqual(unmatched.add_references("zxqv-unmatched-token"), ["D4", "D5"])

    def test_added_source_citations_and_selected_input_boundary(self):
        s = Session()
        for sid in list(s.decisions):
            s.decide(sid, "Exclude")
        s.add_references("adult sleep diary")
        s.decide("D4", "Select")
        s.decide("D5", "Uncertain")
        result = s.generate()
        self.assertEqual(result["input_ids"], ["D4"])
        self.assertEqual([claim["source_id"] for claim in result["claims"]], ["D4"])
        self.assertEqual(result["claims"][0]["quote"], s.source("D4")["passage"])
        self.assertEqual(result["input_passages"], [{"source_id": "D4", "passage": s.source("D4")["passage"]}])
        s.add_references("withdrawn")
        s.decide("D6", "Select")
        result = s.generate()
        self.assertEqual(result["input_ids"], ["D4", "D6"])
        self.assertEqual(result["omitted_selected_ids"], ["D6"])
        self.assertEqual([claim["source_id"] for claim in result["claims"]], ["D4"])

    def test_additional_insufficient_sources_never_support_child_health_conclusion(self):
        s = Session(case_id="insufficient")
        s.add_references("schoolchildren wearable sleep score")
        s.add_references("more evidence")
        for sid in s.decisions:
            s.decide(sid, "Select")
        result = s.generate()
        self.assertEqual(len(result["input_ids"]), 6)
        self.assertEqual(result["status"], "insufficient")
        self.assertEqual(result["claims"], [])
        self.assertEqual(result["omitted_selected_ids"], result["input_ids"])

    def test_reference_search_never_duplicates_and_exhaustion_preserves_state(self):
        s = Session()
        first = s.add_references("diary")
        second = s.add_references("diary")
        self.assertEqual(len(first), 2)
        self.assertEqual(len(second), 1)
        self.assertFalse(set(first).intersection(second))
        self.assertEqual(len(s.decisions), 6)
        self.assertEqual(s.available_reference_count, 0)
        previous = s.decisions.copy()
        with self.assertRaisesRegex(ValueError, "already in your review"):
            s.add_references("different query")
        self.assertEqual(s.decisions, previous)
        self.assertEqual(s.search_query, "diary")

    def test_invalid_reference_queries_do_not_change_current_result(self):
        s = Session()
        previous_result = self.finish(s, ["Select", "Exclude", "Uncertain"])
        for query in ("", " \t\n ", "x" * 201, None, 42, []):
            with self.subTest(query=query):
                with self.assertRaises(ValueError):
                    s.add_references(query)
                self.assertEqual(len(s.case["sources"]), 3)
                self.assertEqual(s.result, previous_result)
                self.assertEqual(s.search_query, "")
        self.assertEqual(len(s.add_references("x" * 200)), 2)

    def test_stop_restart_case_switch_and_reference_catalog_isolation(self):
        cases = load_cases()
        first = Session(cases=cases)
        second = Session(cases=cases)
        first.decide("D1", "Select")
        first.add_references("diary")
        self.assertEqual(len(second.case["sources"]), 3)
        self.assertEqual(second.available_reference_count, 3)
        self.assertEqual(len(cases["diary"]["sources"]), 3)
        self.assertEqual(len(first.cases["diary"]["sources"]), 3)
        first.stop()
        with self.assertRaisesRegex(ValueError, "Restart"):
            first.add_references("more")
        first.change_case("diary")
        self.assertEqual(len(first.case["sources"]), 3)
        self.assertEqual(first.reviewed, 0)
        self.assertEqual(first.available_reference_count, 3)
        self.assertEqual(first.search_query, "")
        first.add_references("diary")
        first.change_case("conflict")
        self.assertEqual(len(first.case["sources"]), 3)
        self.assertEqual(set(first.decisions), {"C1", "C2", "C3"})
        self.assertEqual(first.search_query, "")
        first.change_case("diary")
        self.assertEqual(set(first.decisions), {"D1", "D2", "D3"})

    def test_catalog_without_additional_sources_remains_supported(self):
        cases = load_cases()
        for case in cases.values():
            case.pop("additional_sources")
        s = Session(cases=cases)
        self.assertEqual(s.available_reference_count, 0)
        self.assertNotIn("additional_sources", s.case)
        with self.assertRaises(ValueError):
            s.add_references("diary")

    def test_fixture_schema_validates_additional_fields_and_duplicate_ids(self):
        import copy, json, tempfile
        from pathlib import Path
        original = load_cases()
        malformed = []
        missing = copy.deepcopy(original)
        del missing["diary"]["additional_sources"][0]["passage"]
        malformed.append(missing)
        duplicate = copy.deepcopy(original)
        duplicate["diary"]["additional_sources"][0]["id"] = "D1"
        malformed.append(duplicate)
        wrong_type = copy.deepcopy(original)
        wrong_type["diary"]["additional_sources"] = {}
        malformed.append(wrong_type)
        with tempfile.TemporaryDirectory() as directory:
            p = Path(directory) / "invalid.json"
            for case_data in malformed:
                p.write_text(json.dumps(case_data), encoding="utf-8")
                with self.assertRaises(ValueError):
                    load_cases(p)

    def test_typed_questions_route_to_different_fictional_catalogues(self):
        s = Session()
        self.assertFalse(s.question_submitted)
        self.assertEqual(s.requested_question, "")
        self.assertEqual(s.retrieval_message, "")
        for question, topic, prefix in [
            ("Can a sleep diary help adults describe routines?", "diary", "D"),
            ("How do sleep journals help describe a routine?", "diary", "D"),
            ("Do the Wind-Down pilots agree on calmness?", "conflict", "C"),
            ("What do the relaxation pilots report?", "conflict", "C"),
            ("Are wearable sleep scores useful for schoolchildren?", "insufficient", "I"),
        ]:
            with self.subTest(question=question):
                s.ask_question("  " + question + "  ")
                self.assertTrue(s.question_submitted)
                self.assertEqual(s.case_id, topic)
                self.assertEqual(s.case["question"], question)
                self.assertEqual(s.requested_question, question)
                self.assertEqual(len(s.case["sources"]), 3)
                self.assertTrue(all(source["id"].startswith(prefix) for source in s.case["sources"]))
                self.assertIn("fictional", s.retrieval_message)
                self.assertFalse(s.ready)

    def test_question_tokens_rank_sources_without_changing_fixture_content(self):
        cases = load_cases()
        s = Session(cases=cases)
        s.ask_question("sleep diary workshop adult routine")
        self.assertEqual(s.case["sources"][0]["id"], "D1")
        s.ask_question("sleep diary withdrawal methods unavailable")
        self.assertEqual(s.case["sources"][0]["id"], "D3")
        by_id = {source["id"]: source for source in cases["diary"]["sources"]}
        self.assertTrue(all(source == by_id[source["id"]] for source in s.case["sources"]))
        self.assertEqual(s.cases, cases)

    def test_schoolchildren_homework_question_does_not_retrieve_sleep_sources(self):
        s = Session()
        s.ask_question("How should schoolchildren organise homework?")
        self.assertEqual(s.case_id, "unmatched")
        self.assertEqual(s.case["sources"], [])
        self.assertEqual(s.available_reference_count, 0)
        self.assertFalse(s.ready)
        with self.assertRaises(ValueError):
            s.generate()

    def test_explicit_diary_topic_precedes_schoolchild_sleep_context(self):
        s = Session()
        s.ask_question("Do sleep diaries help schoolchildren?")
        self.assertEqual(s.case_id, "diary")
        self.assertEqual({source["id"] for source in s.case["sources"]}, {"D1", "D2", "D3"})
        self.assertEqual(s.requested_question, "Do sleep diaries help schoolchildren?")
        s.ask_question("Do wearable sleep scores and diaries help schoolchildren?")
        self.assertEqual(s.case_id, "insufficient")
        self.assertEqual({source["id"] for source in s.case["sources"]}, {"I1", "I2", "I3"})

    def test_asking_again_clears_previous_review_output_search_and_stop(self):
        s = Session()
        s.ask_question("sleep diaries")
        for sid in s.decisions:
            s.decide(sid, "Select" if sid == "D1" else "Exclude")
        s.generate()
        s.add_references("diary workshop")
        s.stop()
        s.ask_question("Wind-Down calmness")
        self.assertEqual(s.case_id, "conflict")
        self.assertEqual(set(s.decisions), {"C1", "C2", "C3"})
        self.assertTrue(all(value is None for value in s.decisions.values()))
        self.assertIsNone(s.result)
        self.assertEqual(s.search_query, "")
        self.assertEqual(s.available_reference_count, 3)
        self.assertFalse(s.stopped)

    def test_unsupported_question_has_no_unrelated_fallback_or_generation(self):
        s = Session()
        s.ask_question("Why is the sky blue?")
        self.assertTrue(s.question_submitted)
        self.assertEqual(s.case_id, "unmatched")
        self.assertEqual(s.case["question"], "Why is the sky blue?")
        self.assertEqual(s.case["sources"], [])
        self.assertEqual(s.decisions, {})
        self.assertEqual(s.reviewed, 0)
        self.assertEqual(s.available_reference_count, 0)
        self.assertFalse(s.ready)
        with self.assertRaises(ValueError):
            s.generate()
        with self.assertRaises(ValueError):
            s.add_references("sleep diary")
        self.assertIsNone(s.result)
        s.ask_question("sleep diary")
        self.assertEqual(len(s.case["sources"]), 3)

    def test_invalid_questions_do_not_mutate_existing_session(self):
        import copy
        s = Session()
        s.ask_question("sleep diary")
        for sid in s.decisions:
            s.decide(sid, "Select" if sid == "D1" else "Uncertain")
        s.generate()
        previous = copy.deepcopy(s.__dict__)
        for question in ("", " \t\n ", "x" * 501, None, 42, []):
            with self.subTest(question=question):
                with self.assertRaises(ValueError):
                    s.ask_question(question)
                self.assertEqual(s.__dict__, previous)
        maximum = "sleep diary " + "x" * 488
        self.assertEqual(len(maximum), 500)
        s.ask_question(maximum)
        self.assertEqual(s.requested_question, maximum)

    def test_question_is_preserved_when_adding_references_from_matched_catalogue(self):
        s = Session()
        question = "Do the Wind-Down pilots agree about calmness?"
        s.ask_question(question)
        s.decide("C1", "Select")
        added = s.add_references("adult calmness")
        self.assertEqual(len(added), 2)
        self.assertTrue(all(sid.startswith("C") for sid in added))
        self.assertEqual(s.case["question"], question)
        self.assertEqual(s.requested_question, question)
        self.assertTrue(s.question_submitted)
        self.assertEqual(s.decisions["C1"], "Select")

    def test_supported_topic_does_not_invent_an_answer_to_unmeasured_outcome(self):
        s = Session()
        s.ask_question("Can a sleep diary cure cancer?")
        for sid in s.decisions:
            s.decide(sid, "Select" if sid == "D1" else "Exclude")
        result = s.generate()
        self.assertIn("does not establish", s.retrieval_message)
        self.assertEqual(result["claims"][0]["text"], s.source("D1")["finding"])
        self.assertEqual(result["claims"][0]["quote"], s.source("D1")["passage"])
        self.assertIn("no clinical benefit", result["message"])
        self.assertNotIn("cancer", str(result))

    def test_question_restart_returns_to_input_and_legacy_restart_stays_in_case(self):
        s = Session(case_id="conflict")
        s.restart()
        self.assertEqual(s.case_id, "conflict")
        self.assertFalse(s.question_submitted)
        s.ask_question("wearable sleep scores")
        s.add_references("schoolchildren")
        s.restart()
        self.assertEqual(s.case_id, "diary")
        self.assertFalse(s.question_submitted)
        self.assertEqual(s.requested_question, "")
        self.assertEqual(s.retrieval_message, "")
        self.assertEqual(s.search_query, "")
        self.assertEqual(len(s.case["sources"]), 3)
        self.assertEqual(s.reviewed, 0)

    def test_question_sessions_do_not_share_typed_questions_or_ranked_sources(self):
        cases = load_cases()
        first, second = Session(cases=cases), Session(cases=cases)
        first.ask_question("sleep diary withdrawal methods unavailable")
        self.assertFalse(second.question_submitted)
        self.assertEqual(second.case["question"], cases["diary"]["question"])
        self.assertEqual(second.case["sources"][0]["id"], "D1")
        self.assertEqual(cases["diary"]["sources"][0]["id"], "D1")

    def test_undo_exclusion_preserves_question_and_other_choices(self):
        s = Session()
        s.ask_question("Can a sleep diary help adults describe their routine?")
        for sid, choice in {"D1": "Select", "D2": "Exclude", "D3": "Uncertain"}.items():
            s.decide(sid, choice)
        s.generate()
        question = s.requested_question
        self.assertTrue(s.can_undo_exclusion)
        self.assertEqual(s.undo_last_exclusion(), "D2")
        self.assertEqual(s.decisions, {"D1": "Select", "D2": None, "D3": "Uncertain"})
        self.assertEqual(s.requested_question, question)
        self.assertTrue(s.question_submitted)
        self.assertEqual(s.reviewed, 2)
        self.assertFalse(s.ready)
        self.assertIsNone(s.result)
        self.assertFalse(s.can_undo_exclusion)
        with self.assertRaises(ValueError):
            s.generate()

    def test_undo_exclusions_uses_stack_without_repeated_choice_duplicates(self):
        s = Session()
        s.decide("D1", "Exclude")
        s.decide("D2", "Exclude")
        s.decide("D2", "Exclude")
        self.assertEqual(s.exclusion_history, ["D1", "D2"])
        self.assertEqual(s.undo_last_exclusion(), "D2")
        self.assertEqual(s.last_excluded_source_id, "D1")
        self.assertEqual(s.undo_last_exclusion(), "D1")
        self.assertIsNone(s.last_excluded_source_id)
        with self.assertRaises(ValueError):
            s.undo_last_exclusion()

    def test_reclassification_removes_stale_exclusion_undo_entries(self):
        s = Session()
        s.decide("D1", "Exclude")
        s.decide("D2", "Exclude")
        s.decide("D2", "Select")
        self.assertEqual(s.last_excluded_source_id, "D1")
        self.assertEqual(s.undo_last_exclusion(), "D1")
        self.assertEqual(s.decisions["D2"], "Select")
        self.assertFalse(s.can_undo_exclusion)
        s.decide("D1", "Exclude")
        s.decide("D1", "Uncertain")
        self.assertEqual(s.exclusion_history, [])

    def test_empty_undo_preserves_existing_summary_and_decisions(self):
        import copy
        s = Session()
        for sid in s.decisions:
            s.decide(sid, "Select")
        s.generate()
        previous = copy.deepcopy(s.__dict__)
        with self.assertRaisesRegex(ValueError, "no excluded"):
            s.undo_last_exclusion()
        self.assertEqual(s.__dict__, previous)

    def test_question_restart_and_case_switch_clear_exclusion_history(self):
        s = Session()
        s.decide("D2", "Exclude")
        s.restart()
        self.assertEqual(s.exclusion_history, [])
        s.decide("D1", "Exclude")
        s.ask_question("wind-down calmness")
        self.assertFalse(s.can_undo_exclusion)
        s.decide("C1", "Exclude")
        s.change_case("insufficient")
        self.assertEqual(s.exclusion_history, [])
        self.assertIsNone(s.last_excluded_source_id)
        s.decide("I1", "Exclude")
        s.ask_question("Why is the sky blue?")
        self.assertEqual(s.exclusion_history, [])
        self.assertFalse(s.can_undo_exclusion)

    def test_undo_added_source_preserves_accumulated_collection(self):
        s = Session()
        s.ask_question("sleep diary")
        for sid, choice in {"D1": "Select", "D2": "Exclude", "D3": "Uncertain"}.items():
            s.decide(sid, choice)
        s.add_references("adult sleep diary")
        s.decide("D4", "Exclude")
        s.decide("D5", "Uncertain")
        s.generate()
        self.assertEqual(s.undo_last_exclusion(), "D4")
        self.assertEqual(len(s.case["sources"]), 5)
        self.assertEqual(s.search_query, "adult sleep diary")
        self.assertEqual(s.available_reference_count, 1)
        self.assertEqual(s.decisions["D1"], "Select")
        self.assertEqual(s.decisions["D2"], "Exclude")
        self.assertIsNone(s.decisions["D4"])
        self.assertEqual(s.last_excluded_source_id, "D2")
        self.assertIsNone(s.result)

    def test_stopped_review_cannot_undo_exclusion(self):
        s = Session()
        s.decide("D2", "Exclude")
        s.stop()
        self.assertFalse(s.can_undo_exclusion)
        with self.assertRaisesRegex(ValueError, "Restart"):
            s.undo_last_exclusion()
        self.assertEqual(s.decisions["D2"], "Exclude")

if __name__=="__main__": unittest.main()
