"use strict";

const paths = {
  check: '<path d="m5 12 4 4L19 6"/>',
  close: '<path d="m6 6 12 12M6 18 18 6"/>',
  document: '<path d="M14 3H5v18h14V8l-5-5Z"/><path d="M14 3v5h5M8 12h8M8 16h6"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18"/>',
  users: '<circle cx="9" cy="8" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3M16 5a3 3 0 0 1 0 6M17 14a5 5 0 0 1 4 5v2"/>',
  question: '<circle cx="12" cy="12" r="9"/><path d="M9.5 8.5a2.7 2.7 0 0 1 5 1.5c0 2-2.5 2-2.5 4M12 17h.01"/>',
  search: '<circle cx="10" cy="10" r="7"/><path d="m15 15 6 6"/>',
  chevron: '<path d="m7 10 5 5 5-5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
};
const $ = id => document.getElementById(id);
const choices = {
  Select: { icon: "check", label: "Select", state: "Selected" },
  Exclude: { icon: "close", label: "Exclude", state: "Excluded" },
  Uncertain: { icon: "question", label: "Not sure", state: "Not sure" },
};
let snapshot = null;
let busy = false;
let invalidated = false;
let searchOpen = false;
let referenceQuery = null;
let questionDraft = "";
let recentlyAdded = new Set();
const expandedSources = new Set();
let notificationTimer;
let sourceOpener;

function icon(name) {
  return `<svg viewBox="0 0 24 24" aria-hidden="true">${paths[name] || paths.document}</svg>`;
}
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, character => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[character]);
}
function announce(message) { $("live-status").textContent = message; }
function notify(message, error = false) {
  clearTimeout(notificationTimer);
  $("notification").textContent = message;
  $("notification").classList.toggle("error", error);
  $("notification").hidden = false;
  notificationTimer = setTimeout(() => { $("notification").hidden = true; }, error ? 9000 : 5000);
}
async function api(path, payload) {
  const response = await fetch(`/api/${path}`, {
    method: payload === undefined ? "GET" : "POST", credentials: "same-origin", cache: "no-store",
    ...(payload === undefined ? {} : { headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) }),
  });
  let data;
  try { data = await response.json(); }
  catch { throw new Error("Check that the local prototype server is still running."); }
  if (!response.ok) throw new Error(data.error || "Please try that action again.");
  return data;
}
function focusKey(key) {
  Array.from(document.querySelectorAll("[data-focus-key]")).find(element => element.dataset.focusKey === key)?.focus({ preventScroll: true });
}
async function act(path, payload) {
  if (busy) return;
  busy = true;
  const previousFocus = document.activeElement?.dataset.focusKey;
  let succeeded = false;
  let added = [];
  let restoredSourceId = null;
  document.body.classList.add("busy");
  document.querySelectorAll("#source-list input, #source-list button, #question-form textarea, #question-form button, #change-question, #restart, #undo-exclusion").forEach(element => { element.disabled = true; });
  if (path === "question") $("find-references").textContent = "Finding references…";
  try {
    const previous = snapshot;
    snapshot = await api(path, payload);
    succeeded = true;
    if (path === "decision") {
      if (payload.choice !== "Select" || previous.decisions[payload.source_id] !== "Select") expandedSources.delete(payload.source_id);
      if (previous.result && !snapshot.result) invalidated = true;
      announce(`${payload.source_id}: ${choices[payload.choice].state}.${payload.choice === "Exclude" ? " Removed from the list. Use Undo last exclusion to restore it." : ""}`);
    } else if (path === "undo-exclusion") {
      restoredSourceId = previous.case.sources.find(source => previous.decisions[source.id] === "Exclude" && snapshot.decisions[source.id] === null)?.id;
      if (previous.result && !snapshot.result) invalidated = true;
      searchOpen = false;
      expandedSources.delete(restoredSourceId);
      recentlyAdded.delete(restoredSourceId);
      const message = `${restoredSourceId || "Reference"} restored as unreviewed. Your other choices are saved. Review it before generating a summary.`;
      announce(message);
      notify(message);
    } else if (path === "references") {
      const existing = new Set(previous.case.sources.map(source => source.id));
      added = snapshot.case.sources.filter(source => !existing.has(source.id)).map(source => source.id);
      recentlyAdded = new Set(added);
      searchOpen = false;
      referenceQuery = snapshot.search_query;
      if (previous.result) invalidated = true;
      const message = `${added.length} references added. Your selected sources are saved.`;
      announce(message);
      notify(message);
    } else if (path === "generate") {
      invalidated = false;
      announce("Summary ready.");
    } else if (path === "question" || path === "new-question") {
      invalidated = false;
      searchOpen = false;
      referenceQuery = null;
      recentlyAdded.clear();
      expandedSources.clear();
      announce(path === "question" ? (snapshot.retrieval_message || "References ready to review.") : "Enter your question to find references.");
    }
  } catch (error) {
    notify(error.message || "The local server could not be reached. Please try again.", true);
  } finally {
    busy = false;
    document.body.classList.remove("busy");
    document.querySelectorAll("#question-form textarea, #question-form button, #change-question, #restart").forEach(element => { element.disabled = false; });
    $("find-references").textContent = "Find references";
    render();
    if (succeeded && path === "question") {
      $("sources-title").setAttribute("tabindex", "-1");
      $("sources-title").focus();
    } else if (succeeded && path === "new-question") {
      $("user-question").focus();
    } else if (succeeded && path === "generate") {
      $("summary-panel").scrollIntoView({ behavior: "smooth", block: "nearest" });
      $("result-heading")?.focus({ preventScroll: true });
    } else if (succeeded && restoredSourceId) {
      const element = $("source-" + restoredSourceId);
      element?.scrollIntoView({ behavior: "smooth", block: "nearest" });
      element?.querySelector("[data-inspect]")?.focus({ preventScroll: true });
    } else if (succeeded && added.length) {
      const element = $("source-" + added[0]);
      element?.scrollIntoView({ behavior: "smooth", block: "nearest" });
      element?.querySelector("[data-inspect]")?.focus({ preventScroll: true });
    } else if (succeeded && path === "decision" && payload.choice === "Select") {
      focusKey("toggle-" + payload.source_id);
    } else if (succeeded && path === "decision" && payload.choice === "Exclude") {
      const next = snapshot.case.sources.find(source => snapshot.decisions[source.id] === null);
      const element = (next && $("source-" + next.id)?.querySelector("[data-inspect]")) || document.querySelector("#review-next-step button:not(:disabled)") || $("restart");
      element?.focus();
    } else if (previousFocus) focusKey(previousFocus);
  }
}
function formattedDate(value) {
  return new Date(`${value}T00:00:00Z`).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" });
}
function renderSource(source) {
  const decision = snapshot.decisions[source.id];
  const selected = decision === "Select";
  const expanded = expandedSources.has(source.id);
  const sid = escapeHTML(source.id);
  const heading = selected
    ? `<button class="selected-source-row" data-toggle-source="${sid}" data-focus-key="toggle-${sid}" aria-expanded="${expanded}" aria-controls="source-details-${sid}" aria-label="${expanded ? "Collapse" : "Expand"} selected source ${sid}: ${escapeHTML(source.title)}"><span class="selected-check">${icon("check")}</span><span class="source-id">${sid}</span><span class="selected-source-title" id="title-${sid}">${escapeHTML(source.title)}</span><span class="row-chevron">${icon("chevron")}</span></button>`
    : `<div class="source-card-top"><span class="source-id">${sid}</span><span class="source-state">${recentlyAdded.has(source.id) && !decision ? '<span class="new-reference-label">New</span>' : ""}${decision ? choices[decision].state : ""}</span></div><h3 id="title-${sid}">${escapeHTML(source.title)}</h3>`;
  return `<article class="source-card${selected ? " selected-source" : ""}" id="source-${sid}" aria-labelledby="title-${sid}">${heading}<div class="source-details" id="source-details-${sid}"${selected && !expanded ? " hidden" : ""}><p class="publisher">${escapeHTML(source.publisher)}</p><div class="source-metadata"><span>${formattedDate(source.date)}</span><span>${escapeHTML(source.population)}</span></div><blockquote class="source-passage"><p>${escapeHTML(source.passage)}</p></blockquote><button class="inspect-button" data-inspect="${sid}" data-focus-key="inspect-${sid}" aria-label="Read source ${sid}: ${escapeHTML(source.title)}">Read source</button><fieldset class="choices"><legend class="sr-only">Review decision for source ${sid}</legend>${Object.entries(choices).map(([value, info]) => `<label class="choice ${value.toLowerCase()}"><input type="radio" name="decision-${sid}" value="${value}" data-source="${sid}" data-focus-key="${sid}-${value}"${decision === value ? " checked" : ""}${snapshot.stopped ? " disabled" : ""}>${icon(info.icon)}<span>${info.label}</span></label>`).join("")}</fieldset></div></article>`;
}
function searchMarkup() {
  const query = referenceQuery ?? (snapshot.search_query || snapshot.requested_question || "").slice(0, 200);
  return `<form id="reference-search-form" class="reference-search"><label for="reference-query">Search for more references</label><div class="reference-search-input">${icon("search")}<input type="search" id="reference-query" name="query" value="${escapeHTML(query)}" maxlength="200" required data-focus-key="reference-query" aria-describedby="search-hint"></div><p id="search-hint">Demo search: adds up to two fictional references.</p><div class="next-step-actions"><button class="button button-primary" type="submit" data-focus-key="search-references">Search</button><button class="button button-secondary" type="button" data-action="search-cancel">Cancel</button></div></form>`;
}
function nextStepMarkup() {
  if (snapshot.stopped) return '<section class="next-step-panel"><p class="next-step-description">This review is paused. Choose Start again to continue.</p></section>';
  const available = snapshot.available_reference_count || 0;
  const remaining = snapshot.case.sources.length - snapshot.reviewed;
  const message = snapshot.ready ? "Add more references, or generate your summary." : `Review ${remaining === 1 ? "the remaining reference" : `the remaining ${remaining} references`} before generating a summary.`;
  return `<section class="next-step-panel" id="review-next-step">${searchOpen ? searchMarkup() : `<p class="next-step-description">${snapshot.ready && !available ? "Your references are reviewed. You can generate your summary." : message}</p><div class="next-step-actions">${snapshot.ready && available ? `<button class="button button-secondary" data-action="search-open" data-focus-key="add-references">${icon("plus")}Add more references</button>` : ""}<button class="button button-primary" data-action="generate" data-focus-key="generate"${snapshot.ready ? "" : " disabled"}>${snapshot.result ? "Update summary" : "Generate summary"}</button></div>`}</section>`;
}
function renderSources() {
  if (!snapshot.case.sources.length) {
    $("source-list").innerHTML = '<div class="no-references"><p>Use Change question above to try another search.</p></div>';
    $("source-list").setAttribute("aria-busy", "false");
    return;
  }
  const selected = snapshot.case.sources.filter(source => snapshot.decisions[source.id] === "Select");
  const remaining = snapshot.case.sources.filter(source => !["Select", "Exclude"].includes(snapshot.decisions[source.id]));
  $("source-list").innerHTML = (selected.length ? `<section class="selected-collection" aria-labelledby="selected-title"><div class="collection-heading"><h3 id="selected-title">Selected <span class="count-badge">${selected.length}</span></h3><span>Click to reopen</span></div>${selected.map(renderSource).join("")}</section>` : "") + remaining.map(renderSource).join("") + nextStepMarkup();
  $("source-list").setAttribute("aria-busy", "false");
}
function renderSummary() {
  const result = snapshot.result;
  $("summary-panel").hidden = !result;
  if (!result) { $("summary-content").innerHTML = ""; return; }
  const title = result.status === "insufficient" ? "Not enough evidence to answer" : result.status === "conflict" ? "The selected sources disagree" : "Based on your selected references";
  $("summary-content").innerHTML = `<h3 class="result-heading" id="result-heading" tabindex="-1">${title}</h3><p class="result-message">${escapeHTML(result.message)}</p>${result.claims.map(claim => `<article class="result-claim"><h4><button class="citation-button" data-inspect="${escapeHTML(claim.source_id)}" data-focus-key="cite-${escapeHTML(claim.source_id)}" aria-label="Read cited source ${escapeHTML(claim.source_id)}">${escapeHTML(claim.source_id)}</button>${escapeHTML(claim.text)}</h4><p class="claim-limit">${escapeHTML(claim.limit)}</p></article>`).join("")}<div class="input-summary">Selected sources: ${result.input_ids.length ? result.input_ids.map(escapeHTML).join(", ") : "none"}.${result.omitted_selected_ids.length ? `<br>${result.omitted_selected_ids.map(escapeHTML).join(", ")} could not support a finding.` : ""}<br>Click a citation to read its original passage.</div>`;
}
function render() {
  if (!snapshot) return;
  const submitted = Boolean(snapshot.question_submitted);
  $("question-entry").hidden = submitted;
  $("question-panel").hidden = !submitted;
  $("source-section").hidden = !submitted;
  $("user-question").disabled = false;
  $("find-references").disabled = false;
  $("find-references").textContent = "Find references";
  $("change-question").disabled = false;
  if (!submitted) $("user-question").value = questionDraft;
  $("question").textContent = snapshot.case.question;
  $("source-count").textContent = snapshot.case.sources.filter(source => snapshot.decisions[source.id] !== "Exclude").length;
  const selected = Object.values(snapshot.decisions).filter(value => value === "Select").length;
  $("review-status").textContent = `${snapshot.reviewed} of ${snapshot.case.sources.length} reviewed · ${selected} selected`;
  $("review-status").hidden = !snapshot.case.sources.length;
  $("review-hint").hidden = !snapshot.case.sources.length;
  const excluded = Object.values(snapshot.decisions).filter(value => value === "Exclude").length;
  $("exclusion-recovery").hidden = !submitted || excluded === 0;
  $("excluded-status").textContent = `${excluded} excluded`;
  $("undo-exclusion").disabled = !snapshot.can_undo_exclusion;
  const excludedSource = snapshot.case.sources.find(source => source.id === snapshot.last_excluded_source_id);
  $("undo-exclusion").setAttribute("aria-label", excludedSource ? `Undo exclusion of source ${excludedSource.id}: ${excludedSource.title}. Restore it as unreviewed.` : "Undo last exclusion");
  $("retrieval-status").textContent = snapshot.retrieval_message || "";
  $("review-feedback").hidden = !invalidated;
  $("review-feedback").textContent = "Your sources changed. Review any unreviewed references and generate a new summary.";
  $("restart").disabled = false;
  if (submitted) {
    renderSources();
    renderSummary();
  } else {
    $("source-list").innerHTML = "";
    $("summary-panel").hidden = true;
    $("summary-content").innerHTML = "";
  }
}
function openSource(id, opener) {
  const source = snapshot?.case.sources.find(item => item.id === id);
  if (!source) return;
  sourceOpener = opener;
  $("source-detail").innerHTML = `<span class="source-id">${escapeHTML(id)} · Fictional source</span><h2 id="source-dialog-title" style="margin-top:12px">${escapeHTML(source.title)}</h2><dl class="detail-metadata"><div><dt>Publisher</dt><dd>${escapeHTML(source.publisher)}</dd></div><div><dt>Date</dt><dd>${formattedDate(source.date)}</dd></div><div><dt>Population</dt><dd>${escapeHTML(source.population)}</dd></div><div><dt>Study / document</dt><dd>${escapeHTML(source.design)}</dd></div></dl><section class="detail-block"><h3>Original passage</h3><blockquote>${escapeHTML(source.passage)}</blockquote></section><section class="detail-block"><h3>About this source</h3><p>${escapeHTML(source.document)}</p></section><section class="detail-block detail-limit"><h3>Limitation</h3><p>${escapeHTML(source.limit)}</p></section>`;
  $("source-dialog").showModal();
  $("source-dialog").scrollTop = 0;
}
function closeSource() {
  $("source-dialog").close();
  sourceOpener?.focus({ preventScroll: true });
}
$("source-list").addEventListener("change", event => {
  if (event.target.matches("input[data-source]")) act("decision", { source_id: event.target.dataset.source, choice: event.target.value });
});
$("source-list").addEventListener("click", event => {
  if (busy) return;
  const toggle = event.target.closest("[data-toggle-source]");
  if (toggle) {
    const id = toggle.dataset.toggleSource;
    if (expandedSources.has(id)) expandedSources.delete(id); else expandedSources.add(id);
    renderSources();
    focusKey("toggle-" + id);
    return;
  }
  const button = event.target.closest("[data-action]");
  if (!button) return;
  if (button.dataset.action === "search-open") {
    searchOpen = true;
    renderSources();
    $("reference-query").focus();
    $("reference-query").select();
  } else if (button.dataset.action === "search-cancel") {
    searchOpen = false;
    renderSources();
    focusKey("add-references");
  } else if (button.dataset.action === "generate") act("generate", {});
});
$("source-list").addEventListener("input", event => {
  if (event.target.id === "reference-query") {
    referenceQuery = event.target.value;
    event.target.setCustomValidity("");
  }
});
$("source-list").addEventListener("submit", event => {
  if (event.target.id !== "reference-search-form") return;
  event.preventDefault();
  const input = $("reference-query");
  if (!input.value.trim()) {
    input.setCustomValidity("Enter a topic to search for.");
    input.reportValidity();
    return;
  }
  act("references", { query: input.value.trim() });
});
document.addEventListener("click", event => {
  const button = event.target.closest("[data-inspect]");
  if (button) openSource(button.dataset.inspect, button);
});
$("question-form").addEventListener("input", () => {
  questionDraft = $("user-question").value;
  $("user-question").setCustomValidity("");
});
$("question-form").addEventListener("submit", event => {
  event.preventDefault();
  const input = $("user-question");
  if (!input.value.trim()) {
    input.setCustomValidity("Enter your question first.");
    input.reportValidity();
    return;
  }
  questionDraft = input.value;
  act("question", { question: input.value.trim() });
});
$("change-question").addEventListener("click", () => {
  questionDraft = snapshot.requested_question || snapshot.case.question;
  act("new-question", {});
});
$("restart").addEventListener("click", () => {
  questionDraft = "";
  act("new-question", {});
});
$("undo-exclusion").addEventListener("click", () => act("undo-exclusion", {}));
$("source-close").addEventListener("click", closeSource);
$("source-done").addEventListener("click", closeSource);
$("source-dialog").addEventListener("click", event => {
  if (event.target !== $("source-dialog")) return;
  const rect = $("source-dialog").getBoundingClientRect();
  if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) closeSource();
});
async function initialise() {
  try {
    snapshot = await api("session");
    $("load-error")?.remove();
    if (snapshot.question_submitted) questionDraft = snapshot.requested_question;
    render();
  } catch (error) {
    const previousError = $("load-error");
    if (previousError) previousError.remove();
    $("question-entry").insertAdjacentHTML("beforeend", `<div class="loading-card error-card" id="load-error"><p>${escapeHTML(error.message || "Check that the local server is running.")}</p><button class="button button-secondary" id="retry">Try again</button></div>`);
    $("retry").addEventListener("click", initialise);
    $("source-list").setAttribute("aria-busy", "false");
  }
}
document.querySelectorAll("[data-icon]").forEach(element => { element.innerHTML = icon(element.dataset.icon); });
initialise();
