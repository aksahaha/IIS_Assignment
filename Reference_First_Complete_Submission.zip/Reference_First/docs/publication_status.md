# Repository links

- Repository: [IIS Assignment](https://github.com/aksahaha/IIS_Assignment)
- README: [Project README](https://github.com/aksahaha/IIS_Assignment#readme)

The repository URL was provided for this project. Preparing these documents did not upload or change files in that repository.

Local implementation and checks are linked in the [development evidence](development_evidence.md).
