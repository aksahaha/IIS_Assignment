# Reference First Project and Development Report

Intelligent Interactive Systems Assignment 2

24 November 2026

Total report word count 1287

Main report 1096 words    Abstract 191 words

Counts include title, headings and in-text citations. Short figure labels and captions, references and project links are excluded.

## Abstract

Reference First is a local prototype for non-specialist adults practising how to inspect evidence before using a health-information summary. The user types a question, receives candidate fictional references and records Select, Exclude or Not sure for each. Only selected passages may support the subsequent summary. Selected sources collapse into expandable rows; further searches preserve previous decisions while requiring review of additions.

The implemented browser, Python HTTP API and state engine provide question entry, review controls, citation inspection, undo and reset. Retrieval, source eligibility, disagreement detection and summary generation are deterministic simulations over three authored topic collections. Unsupported questions return no references; unsuitable selections produce no supported answer; conflicting findings remain unresolved. No live search, generative model, patient data or clinical evaluation is involved.

The design applies capability disclosure, recognition, feedback, agency, hybrid interaction, context assembly and provenance from Weeks 1-4. Its development records feedback from the project requester, including requests to simplify navigation and make retrieval depend on a typed question. Automated checks and browser walkthroughs demonstrate software behaviour, not successful evidence appraisal. Required review remains a design hypothesis to compare with optional checking through future user and expert evaluation.

## Target task and scope

The intended user is a non-specialist adult checking a non-urgent health explanation. Their task is to inspect evidence, choose permitted inputs and trace claims. Assignment 1 identified a gap between references and active checking: 38 of Degachi et al.'s 57 participants opened no source link [1]. Yu et al. found higher verification intentions with bundled cues, but their adjusted source-opening estimate was inconclusive [2]. Neither establishes that compulsory review improves judgement.

The prototype accepts a question and retrieves three candidate fictional sources for sleep diaries, calmness or wearable sleep scores. Unsupported topics receive no matches. Authored fixtures make irrelevant, withdrawn, conflicting and insufficient evidence reproducible without API keys or real patient data. Live retrieval, generative AI and clinical appraisal remain planned.

## Interaction choices and alternatives

An answer-first interface would provide immediate output, but checking would follow an already presented conclusion. Optional source review would reduce compulsory actions, while allowing unexamined material into context. I chose explicit review before generation to make input permission observable. That choice develops Assignment 1's research question; it is not an established remedy for automation bias. Readers can still classify mechanically or gain unjustified confidence. Compulsory source opening would record a click without establishing understanding.

Week 1 guidelines G1-G2 informed capability disclosure [4]. The opening screen labels the simulation and suggests supported topics; unmatched questions expose the boundary instead of returning unrelated references. Week 3 hybrid interaction combines a natural-language question with structured decisions [8]. A long chat transcript could support clarification, but would obscure the current evidence set and add conversational complexity.

Week 2 recognition and external memory motivated source metadata, saved choices and expandable selected rows [6]. Reopening a document reduces dependence on recall, although collapsed detail adds effort when comparing sources. Feedback and agency informed review counts, disabled generation and Not sure, which records uncertainty without permission [5,7]. Exclusions disappear as requested. Undo last exclusion restores the latest as unreviewed, preserves other decisions and clears output, so generation remains blocked until review.

## Architecture and evidence boundaries

The browser sends JSON requests to the local Python API. A decision contains source_id and choice; the allowed choices are Select, Exclude and Uncertain; questions must be nonblank strings of at most 500 characters. Unknown IDs or invalid labels are rejected before state changes. The engine routes supported topics, ranks by token overlap and stores decisions separately from source text. Server-side gating rejects generation while references remain unreviewed, even if the disabled button is bypassed. This applies Week 4's model/system boundary: code governs a future model's permitted inputs [9].

Week 4 context assembly informed the explicit record of selected IDs and exact passages [10]. Adding references preserves existing choices, starts additions unreviewed and invalidates the summary. Changing the question discards the previous context. Refresh retains the current session; stopping the server loses it. These are bounded continuity rules, not persistent personal memory. Context fields input_ids and input_passages are inspectable in docs/context_example.json.

Provenance requires inspectable support [11]. Citation buttons reopen original passages and limitations. VERICITE distinguishes retrieval coverage from citation faithfulness, but its automated evaluator lacked human validation [3]. This motivates traceability without claiming that a working citation guarantees correctness. Keyword similarity also misses population and outcome differences; authored eligibility labels do not independently validate a question's medical premise.

A diary question about improved sleep can retrieve a study of routine descriptions. Its summary must retain that narrower finding rather than imply measured clinical benefit.

![System diagram](system_diagram.svg)

Figure 1 Components and information or control flows. I implemented, S simulated, P planned.

## Illustrated interaction

Figures 2-4 show actual interface states. The first walkthrough asks whether diaries help adults describe sleep routines. D1 is selected, D2 excluded and D3 marked Not sure. D1 becomes a compact row; its summary citation opens the original passage and limitation. Adding D4/D5 retains D1 but requires new decisions before generation.

The second asks about calmness. Selecting C1 and C2 displays opposing findings without an overall effect. Reopening C2 and changing it to Not sure clears the old result; regeneration uses C1 alone. The third selects adult wearable evidence for a schoolchildren question and receives no supported answer. Undo restores I2 for review. An unrelated question returns no references. Start again restores blank question input.

## Development feedback and verification

The initial desktop interface became a browser prototype. The project requester then asked for selected cards to shrink, exclusions to disappear, unnecessary navigation to be removed and questions to accept input. These are identifiable project feedback requests, not findings from recruited participants. Each revision preserved the underlying source-permission boundary while changing its presentation.

Report review then exposed the cost of restoring an accidental exclusion. I added Undo last exclusion instead of requiring a complete restart. The restored source is unreviewed; existing selections remain, while any previous summary is cleared. This responds to design critique, not evidence from a user study.

A concrete failure appeared in topic matching: an unrelated question containing schoolchildren could trigger wearable results. Matching was tightened so that schoolchildren alone does not select that collection. Another risk was stale output after revised evidence; changing decisions or adding sources now removes the previous result. These corrections distinguish an interaction failure from an unsupported claim of improved health reasoning.

The 62 passing engine/API tests cover validation, routing, no matches, session isolation, resets, source filtering and citation passages. tests/test_engine.py includes all 81 choice combinations across the original three cases; it does not exhaust every expanded collection. tests/test_web.py checks the HTTP boundary and additional-reference workflow. Browser walkthroughs exercised question entry, reopening, exclusion, extra references, citations, refresh and phone layout. Undo tests check preserved decisions and renewed gating. The README links stages E1-E6 to code, checks and saved output.

## Reflection and next steps

The principal lesson is that a recorded choice does not demonstrate understanding. The inspector exposes population, date, document type and limitations, but novices can select unsuitable evidence. Yu et al.'s 200 older Chinese adults saw static screenshots, bundled cues and no incorrect answers, limiting transfer to error detection here [2]. Undo provides local recovery; its effect on appraisal and workload is untested.

Next steps are genuine retrieval and independently checked model outputs. A required-versus-optional review study should hold starting materials and model instructions consistent while measuring source suitability, answer faithfulness, abstention, workload and confidence. Expert appraisal and observed user reasoning would complement opening logs. Such evaluation is necessary before claiming that the workflow improves evidence selection or health-information quality.

## Figure 2 Review and extend the evidence

USER Ask about adult sleep diaries > Select D1 > Exclude D2 > Not sure D3 > Add references > Review D4 D5 > Generate

<figure class='screenshot-panel' style='margin:16px 0'><figcaption style='font:600 14px/1.5 Arial,sans-serif;margin-bottom:7px'>1  SYSTEM D1 saved as a compact row; D2 hidden</figcaption>
<div class='screenshot-crop' style='position:relative;overflow:hidden;width:100%;border:1px solid #bcc9bf;background:white;aspect-ratio:775/145;max-width:780px;'><img src='screenshots/03_reviewed.jpg' style='position:absolute;height:auto;max-width:none;display:block;width:196.258065%;left:-48.387097%;top:-13.793103%;' alt='1  SYSTEM D1 saved as a compact row; D2 hidden'>
<span class='screenshot-marker' style='position:absolute;transform:translate(-50%,-50%);display:grid;place-items:center;width:23px;height:23px;border:2px solid white;border-radius:50%;background:#a45712;color:white;font:bold 13px Arial,sans-serif;left:97.41935%;top:75.86207%'>1</span>
</div></figure>

<figure class='screenshot-panel' style='margin:16px 0'><figcaption style='font:600 14px/1.5 Arial,sans-serif;margin-bottom:7px'>2  SYSTEM D4 is new and needs a decision; D1 remains saved</figcaption>
<div class='screenshot-crop' style='position:relative;overflow:hidden;width:100%;border:1px solid #bcc9bf;background:white;aspect-ratio:775/325;max-width:780px;'><img src='screenshots/04_new_review_gate.jpg' style='position:absolute;height:auto;max-width:none;display:block;width:196.258065%;left:-48.387097%;top:-110.769231%;' alt='2  SYSTEM D4 is new and needs a decision; D1 remains saved'>
<span class='screenshot-marker' style='position:absolute;transform:translate(-50%,-50%);display:grid;place-items:center;width:23px;height:23px;border:2px solid white;border-radius:50%;background:#a45712;color:white;font:bold 13px Arial,sans-serif;left:97.41935%;top:9.23077%'>2</span>
</div></figure>

<figure class='screenshot-panel' style='margin:16px 0'><figcaption style='font:600 14px/1.5 Arial,sans-serif;margin-bottom:7px'>3  SYSTEM D1 and D4 findings with limits; citations open sources</figcaption>
<div class='screenshot-crop' style='position:relative;overflow:hidden;width:100%;border:1px solid #bcc9bf;background:white;aspect-ratio:775/402;max-width:780px;'><img src='screenshots/05_diary_summary.jpg' style='position:absolute;height:auto;max-width:none;display:block;width:196.258065%;left:-48.387097%;top:-70.895522%;' alt='3  SYSTEM D1 and D4 findings with limits; citations open sources'>
<span class='screenshot-marker' style='position:absolute;transform:translate(-50%,-50%);display:grid;place-items:center;width:23px;height:23px;border:2px solid white;border-radius:50%;background:#a45712;color:white;font:bold 13px Arial,sans-serif;left:97.41935%;top:42.28856%'>3</span>
</div></figure>

Actual prototype captures. Markers identify saved input, an added source and cited output. All evidence is fictional.

## Figure 3 Compare disagreement and correct a choice

USER Ask about calmness > Select C1 C2 > Exclude C3 > Generate > Reopen C2 > Choose Not sure > Generate again

<figure class='screenshot-panel' style='margin:16px 0'><figcaption style='font:600 14px/1.5 Arial,sans-serif;margin-bottom:7px'>1  SYSTEM Opposing findings; no overall effect inferred</figcaption>
<div class='screenshot-crop' style='position:relative;overflow:hidden;width:100%;border:1px solid #bcc9bf;background:white;aspect-ratio:775/402;max-width:780px;'><img src='screenshots/07_conflict.jpg' style='position:absolute;height:auto;max-width:none;display:block;width:196.258065%;left:-48.387097%;top:-70.895522%;' alt='1  SYSTEM Opposing findings; no overall effect inferred'>
<span class='screenshot-marker' style='position:absolute;transform:translate(-50%,-50%);display:grid;place-items:center;width:23px;height:23px;border:2px solid white;border-radius:50%;background:#a45712;color:white;font:bold 13px Arial,sans-serif;left:97.41935%;top:28.10945%'>1</span>
</div></figure>

<figure class='screenshot-panel' style='margin:16px 0'><figcaption style='font:600 14px/1.5 Arial,sans-serif;margin-bottom:7px'>2  SYSTEM Previous output cleared; C1 retained and C2 marked Not sure</figcaption>
<div class='screenshot-crop' style='position:relative;overflow:hidden;width:100%;border:1px solid #bcc9bf;background:white;aspect-ratio:775/625;max-width:780px;'><img src='screenshots/08_correction.jpg' style='position:absolute;height:auto;max-width:none;display:block;width:196.258065%;left:-48.387097%;top:-4.800000%;' alt='2  SYSTEM Previous output cleared; C1 retained and C2 marked Not sure'>
<span class='screenshot-marker' style='position:absolute;transform:translate(-50%,-50%);display:grid;place-items:center;width:23px;height:23px;border:2px solid white;border-radius:50%;background:#a45712;color:white;font:bold 13px Arial,sans-serif;left:97.41935%;top:5.12000%'>2</span>
<span class='screenshot-marker' style='position:absolute;transform:translate(-50%,-50%);display:grid;place-items:center;width:23px;height:23px;border:2px solid white;border-radius:50%;background:#a45712;color:white;font:bold 13px Arial,sans-serif;left:97.41935%;top:73.92000%'>3</span>
</div></figure>

Actual prototype captures. Correction removes the earlier result; regeneration uses C1 alone. Selected sources remain reopenable.

## Figure 4 Insufficient evidence and local recovery

USER Ask about wearable scores for schoolchildren > Select I1 > Exclude I2 > Not sure I3 > Generate > Undo last exclusion

<figure class='screenshot-panel' style='margin:16px 0'><figcaption style='font:600 14px/1.5 Arial,sans-serif;margin-bottom:7px'>1  SYSTEM I1 supplies no supported finding for the question</figcaption>
<div class='screenshot-crop' style='position:relative;overflow:hidden;width:100%;border:1px solid #bcc9bf;background:white;aspect-ratio:775/262;max-width:780px;'><img src='screenshots/10_insufficient.jpg' style='position:absolute;height:auto;max-width:none;display:block;width:196.258065%;left:-48.387097%;top:-162.213740%;' alt='1  SYSTEM I1 supplies no supported finding for the question'>
<span class='screenshot-marker' style='position:absolute;transform:translate(-50%,-50%);display:grid;place-items:center;width:23px;height:23px;border:2px solid white;border-radius:50%;background:#a45712;color:white;font:bold 13px Arial,sans-serif;left:97.41935%;top:30.53435%'>1</span>
</div></figure>

<figure class='screenshot-panel' style='margin:16px 0'><figcaption style='font:600 14px/1.5 Arial,sans-serif;margin-bottom:7px'>2  SYSTEM Undo restores I2 unreviewed and preserves I1</figcaption>
<div class='screenshot-crop' style='position:relative;overflow:hidden;width:100%;border:1px solid #bcc9bf;background:white;aspect-ratio:775/490;max-width:780px;'><img src='screenshots/11_undo_restored.jpg' style='position:absolute;height:auto;max-width:none;display:block;width:196.258065%;left:-48.387097%;top:-39.795918%;' alt='2  SYSTEM Undo restores I2 unreviewed and preserves I1'>
<span class='screenshot-marker' style='position:absolute;transform:translate(-50%,-50%);display:grid;place-items:center;width:23px;height:23px;border:2px solid white;border-radius:50%;background:#a45712;color:white;font:bold 13px Arial,sans-serif;left:97.41935%;top:24.89796%'>2</span>
<span class='screenshot-marker' style='position:absolute;transform:translate(-50%,-50%);display:grid;place-items:center;width:23px;height:23px;border:2px solid white;border-radius:50%;background:#a45712;color:white;font:bold 13px Arial,sans-serif;left:97.41935%;top:46.53061%'>3</span>
</div></figure>

<figure class='screenshot-panel' style='margin:16px 0'><figcaption style='font:600 14px/1.5 Arial,sans-serif;margin-bottom:7px'>3  SYSTEM Summary cleared; generation waits for another decision</figcaption>
<div class='screenshot-crop' style='position:relative;overflow:hidden;width:100%;border:1px solid #bcc9bf;background:white;aspect-ratio:775/110;max-width:780px;'><img src='screenshots/12_undo_gate.jpg' style='position:absolute;height:auto;max-width:none;display:block;width:196.258065%;left:-48.387097%;top:-450.909091%;' alt='3  SYSTEM Summary cleared; generation waits for another decision'>
<span class='screenshot-marker' style='position:absolute;transform:translate(-50%,-50%);display:grid;place-items:center;width:23px;height:23px;border:2px solid white;border-radius:50%;background:#a45712;color:white;font:bold 13px Arial,sans-serif;left:97.41935%;top:71.81818%'>4</span>
</div></figure>

Actual prototype captures. Insufficiency uses authored fixture labels. Undo is an implemented control, not an AI judgement.

## Repository and development evidence

[Repository](https://github.com/aksahaha/IIS_Assignment)

[README and development record](https://github.com/aksahaha/IIS_Assignment#readme)

[Development evidence](development_evidence.md)

[Recorded verification results](verification_results.txt)

[Selected context example](context_example.json)

[Schematic interaction overview](storyboards.svg)

## References

[1] Degachi, S., Niforatos, E. and Kortuem, G. (2026). The effect of agent persona on source-clicking, reliance and trust in generative conversational search and the moderating role of health literacy. Behaviour & Information Technology, 45(18), 4405-4430. https://doi.org/10.1080/0144929X.2026.2638907

[2] Yu, J., Chen, J., Ren, A., Duan, H., Meng, H. and Gao, Z. (2026). Effects of a Safety User Interface Bundle on Verification Intentions in Generative AI Chat Use Among Older Chinese Adults: Randomized Vignette Survey. Journal of Medical Internet Research, 28, e94140. https://doi.org/10.2196/94140

[3] Ma, Y., Chu, B. and Fuhr, N. (2026). VERICITE: Evaluating Sentence-Level Citation Faithfulness in Retrieval-Augmented Medical Question Answering. Proceedings of the 25th Workshop on Biomedical Language Processing, 753-759. https://doi.org/10.18653/v1/2026.bionlp-1.62

[4] IIS module materials (Weeks 1-4). L03 Human Centred Intelligent Interaction and the Shape of the Module, PDF pp. 7, 12. G1-G2 capability disclosure.

[5] IIS module materials (Week 2). L04 Perception Attention and Feedback, PDF pp. 18, 20.

[6] IIS module materials (Week 2). L05 Memory Mental Models and Cognitive Load, PDF pp. 4, 8, 10-11.

[7] IIS module materials (Week 2). L06 Action Error Agency and Decision, PDF pp. 12-14.

[8] IIS module materials (Week 3). L07 Conversational Interfaces, PDF pp. 5, 12, 16.

[9] IIS module materials (Week 4). L12 Tools Connectors Structured Output and the Model System Boundary, PDF pp. 5, 8.

[10] IIS module materials (Week 4). L10 Context Engineering and Memory, PDF p. 8.

[11] IIS module materials (Week 4). L11 Retrieval Grounding and Provenance, PDF pp. 7-10, 13, 15-16.

## Acknowledgements

The project develops the reference-first proposal and literature from Assignment 1. OpenAI Codex assisted code, tests, report drafting, diagrams and screenshot annotation. Sources, test output, state transitions, word counts and rendered pages were checked. All prototype publishers, studies and findings are fictional. See README AI assistance and development evidence E1-E6.
