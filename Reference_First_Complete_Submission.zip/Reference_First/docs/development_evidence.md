# Development evidence

Compiled on 24 November 2026. E1-E6 group significant changes and their current inspectable evidence by development stage. Requester feedback below paraphrases requests from this work session. It is project feedback, not a participant study. Implementation choices are identified separately.

<a id="e1"></a>
## E1 - Bounded simulator and review boundary

- **Basis:** the Assignment 1 reference-first proposal and the assignment's allowance for implementations, prototypes and simulations. Using authored fixtures was an implementation choice.
- **Change and reason:** separated review state from presentation and used fictional sources to make the workflow reproducible without API keys or invented claims about real studies.
- **Source:** [Session and generation rules](../engine.py#L61), [selected-input assembly](../engine.py#L200) and [fictional documents](../fixtures.json).
- **Checks:** [review gate](../tests/test_engine.py#L9), [exact citation passage](../tests/test_engine.py#L16), [all 81 initial-case decision combinations](../tests/test_engine.py#L71) and [withdrawn-source rejection](../tests/test_engine.py#L88).
- **Limit:** eligibility and disagreement use authored `kind` and `direction` labels. The checks establish the selected-input rule, not medical validity, reading or comprehension.

<a id="e2"></a>
## E2 - Compact selections and hidden exclusions

- **Requester basis:** selected references should become compact rows that can be reopened; excluded sources should disappear. The later request authorized prototype improvements where needed. Undo was an implementation response to the documented recovery cost, not participant feedback.
- **Change and reason:** [renderSource and renderSources](../web/prototype.js#L143) retain selected rows and hide exclusions. [Decision changes](../engine.py#L169) clear stale output. [undo_last_exclusion](../engine.py#L181) restores the latest exclusion as unreviewed, preserves other choices and re-locks generation. The small recovery control stays outside the source list; repeated undo works backwards through current exclusions.
- **Checks:** [preservation and gate](../tests/test_engine.py#L407), [history order and no-op repeats](../tests/test_engine.py#L426), [reclassification cleanup](../tests/test_engine.py#L439), [empty-history safety](../tests/test_engine.py#L452), [reset](../tests/test_engine.py#L463), [added-source recovery](../tests/test_engine.py#L480) and [HTTP state/session isolation](../tests/test_web.py#L314). Current visual evidence belongs in [screenshots](screenshots/).
- **Limit:** these automated checks validate state and HTTP behaviour, not DOM layout or focus. Undo restores an unreviewed source rather than silently selecting it. New questions and full resets clear the exclusion history; no cross-session history is retained.

<a id="e3"></a>
## E3 - Add references without losing earlier choices

- **Requester basis:** allow more references to be added after reviewing the existing collection.
- **Change and reason:** [add_references](../engine.py#L147) ranks unused fictional sources, adds at most two, retains earlier decisions and requires review of the additions. Existing output is cleared to prevent a summary from representing obsolete input.
- **Checks:** [preserved decisions and generation gate](../tests/test_engine.py#L105), [added-source citations](../tests/test_engine.py#L134), [duplicate prevention and exhaustion](../tests/test_engine.py#L165) and [HTTP search-to-summary flow](../tests/test_web.py#L194).
- **Limit:** each topic has only three additional fixtures. Search is local token overlap; unmatched additional-search terms fall back to remaining fixtures within the matched topic. This is distinct from an unsupported initial question, which returns no references.

<a id="e4"></a>
## E4 - Simplify the browser review

- **Requester basis:** the version with three scenario tabs and extra panels was too complicated; the requester asked for a simpler prototype.
- **Change and reason:** [the browser page](../web/index.html) uses a single linear question-review-summary flow. [Rendering](../web/prototype.js#L182) hides references before submission and hides the summary until generation. The older desktop remains separate in [app.py](../app.py).
- **Checks:** the [question/new-question HTTP flow](../tests/test_web.py#L279) checks state reset. [Current screenshots](screenshots/) illustrate the resulting interface, not historical before-and-after versions.
- **Limit:** a successful state test does not establish that the simplified interface is easier to use. No participant comparison was performed. The browser no longer exposes a Stop button even though the legacy engine/API supports stopping.

<a id="e5"></a>
## E5 - Retrieve from the entered question and expose no matches

- **Requester basis:** references should follow the user's typed question rather than appear for a prefilled example.
- **Change and reason:** [question_topic](../engine.py#L22) and [ask_question](../engine.py#L112) route and rank three fictional topic collections. Unsupported questions return zero sources. A new question resets previous decisions and output. The schoolchildren/homework false match was corrected during verification.
- **Checks:** [topic selection](../tests/test_engine.py#L249), [question-dependent ordering](../tests/test_engine.py#L272), [homework rejection and diary precedence](../tests/test_engine.py#L283), [no-match gate](../tests/test_engine.py#L320), [question validation](../tests/test_engine.py#L339) and [HTTP session isolation](../tests/test_web.py#L301).
- **Limit:** keyword routing is not general language understanding. Matching a topic does not validate each population or outcome; an adult diary fixture can still be returned for a children's diary question. Summaries describe authored findings rather than inventing an answer to that wording.

<a id="e6"></a>
## E6 - Inspectable verification and portable delivery

- **Requester basis:** provide a downloadable prototype with an assignment-compliant README and clearer development evidence.
- **Change and reason:** [README](../README.md) links the implementation, this record and verification output. [The complete-package builder](../tools/package_submission.py) includes source, browser files, tests, tools, documentation and the report PDF, with internal package-integrity records.
- **Recorded check:** [verification_results.txt](verification_results.txt) contains the 24 November 2026 command, interpreter, working directory, exit code and actual verbose output: **62 tests passed** (42 engine and 20 HTTP tests). Replay with `python -m unittest discover -s tests -v`.
- **Limit:** the [repository URL](https://github.com/aksahaha/IIS_Assignment) and [README URL](https://github.com/aksahaha/IIS_Assignment#readme) were provided for this project. No repository upload was performed during preparation. The test log is software evidence, not a user study, clinical evaluation or live-model assessment.

The current [report](../output/pdf/Reference_First_A2_Report.pdf) explains the rationale and tradeoffs. Screenshots document current states only. Historical claims above are grouped implementation decisions and requester feedback; no participant quotations or trial results are implied.
